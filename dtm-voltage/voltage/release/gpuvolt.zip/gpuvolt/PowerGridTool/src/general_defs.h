
#define ABS(a) (((a)>0)?(a):-(a))
#define MAX(a,b) (((a)>(b))?(a):(b))
#define MIN(a,b) (((a)<(b))?(a):(b))

#define MAX_UNITS 5
#define MAX_TOTAL_UNITS 8

#define MAX_MARGIN 30
#define VDD 1.0
#define THROTTLE_CYCLES 10
#define MAX_CHIPS 100
#define WINDOW_SIZE 100000

#define NO_UNIT_IN_FAULT 0x00
#define IFU_IN_FAULT 0x01
#define IDU_IN_FAULT 0x02
#define FXU_IN_FAULT 0x04
#define FPU_IN_FAULT 0x08
#define LSU_IN_FAULT 0x10


#define CKT_STEP 1/(7e8)
//#define CKT_STEP 1/(5e9)

enum {IFU,
      IDU,
      FXU,
      FPU,
      LSU,
      VMX,
      DFU,
      RU,
      IFU_IDU_LSU,
      IDU_IFU_RU_LSU_FXU,
      FXU_LSU_FPU_IDU,
      LSU_IFU_IDU_FPU_FXU,
      FPU_LSU_DFU_VMX,
     };

