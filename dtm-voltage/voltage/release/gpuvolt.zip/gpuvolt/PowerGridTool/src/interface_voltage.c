#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include "gzip_util.h"
#include "ckt.h"
#include "cktsolver_utils.h"
#include "general_defs.h"


/***********************************************************/
#define MAX_POWER 40
#define MAX_CORES 32
#define STEP 0
#define RAND 1


#define MIN(a,b) (((a)<(b))?(a):(b))


/***********************************************************/
int voltage_model_init = 0;
ckt_t *my_ckt;
unsigned long long voltage_sim_cycle;
double core_grid_r_value = 0;
double non_core_grid_r_value = 0;
unsigned number_of_components_t = 24;

int number_of_points_per_core;
double * node_voltage = NULL;
extern int number_of_cores;

int g_use_current_folder_ckt = 0;

/***********************************************************/
void init_distributed_voltage_model (){
    char ckt_file[512],map_file[512], r_file[512];

	number_of_components_t = number_of_cores ;
	number_of_points_per_core = 3*2;
 	node_voltage = (double *)(malloc((number_of_points_per_core*number_of_cores+1)*sizeof(double)));

    ckt_file[0]='\0';
    map_file[0]='\0';
    r_file[0]='\0';

	char * gpgpusim_root_str;
	gpgpusim_root_str = getenv ("GPGPUSIM_ROOT");
	if (gpgpusim_root_str == NULL) {
		fprintf(stderr, "GPGPUSIM_ROOT not define\n");
		exit(2);
	}
	

	if ( g_use_current_folder_ckt ) {
		printf("using the ckt files in the current directory!\n");
    	sprintf(ckt_file,"./fermi.ckt");
    	sprintf(map_file,"./fermi.map");
    	sprintf(r_file,"./fermi.grid.r");
	} else {
    	sprintf(ckt_file,"%s/../gpuvolt/PowerGridTool/cktfiles/fermi.ckt", gpgpusim_root_str);
    	sprintf(map_file,"%s/../gpuvolt/PowerGridTool/cktfiles/fermi.map", gpgpusim_root_str);
    	sprintf(r_file,"%s/../gpuvolt/PowerGridTool/cktfiles/fermi.grid.r", gpgpusim_root_str);
	}
	FILE * r_fp = fopen (r_file, "r");
	assert(r_fp!=NULL);
	char r_value_str[100];
	fgets(r_value_str, 99, r_fp); 
	r_value_str[strlen(r_value_str)-1] = '\0';
	core_grid_r_value = atof(r_value_str);
	fprintf(stderr, "core r value = %f\n", core_grid_r_value);

	fgets(r_value_str, 99, r_fp); 
	r_value_str[strlen(r_value_str)-1] = '\0';
	non_core_grid_r_value = atof(r_value_str);
	fprintf(stderr, "non core r value = %f\n", non_core_grid_r_value);
	fclose(r_fp);


    /* perform an initialization of the circuit */
    my_ckt = ckt_init(ckt_file,map_file, CKT_STEP);
    int j=0;
    while(j < 2000){
        initialize_distributed_voltage();
        j++;
    }

	voltage_model_init = 1;
    return;
}

void init_distributed_voltage_model_with_arg (unsigned ratio){

    char ckt_file[512],map_file[512], r_file[512];

    ckt_file[0]='\0';
    map_file[0]='\0';
    r_file[0]='\0';

	char * gpgpusim_root_str;
	gpgpusim_root_str = getenv ("GPGPUSIM_ROOT");
	if (gpgpusim_root_str == NULL) {
		fprintf(stderr, "GPGPUSIM_ROOT not define\n");
		exit(2);
	}

    sprintf(ckt_file,"%s/../voltage_model/PowerGridTool/cktfiles/fermi.%d.ckt",gpgpusim_root_str,ratio);
    sprintf(map_file,"%s/../voltage_model/PowerGridTool/cktfiles/fermi.map",gpgpusim_root_str);

    sprintf(r_file,"%s/../voltage_model/PowerGridTool/cktfiles/fermi.grid.r",gpgpusim_root_str);
	FILE * r_fp = fopen (r_file, "r");
	assert(r_fp!=NULL);
	char r_value_str[100];
	fgets(r_value_str, 99, r_fp); 
	r_value_str[strlen(r_value_str)-1] = '\0';
	core_grid_r_value = atof(r_value_str);
	fprintf(stderr, "core r value = %f\n", core_grid_r_value);

	fgets(r_value_str, 99, r_fp); 
	r_value_str[strlen(r_value_str)-1] = '\0';
	non_core_grid_r_value = atof(r_value_str);
	fprintf(stderr, "non core r value = %f\n", non_core_grid_r_value);
	fclose(r_fp);


    /* perform an initialization of the circuit */
    my_ckt = ckt_init(ckt_file,map_file, CKT_STEP);
    int j=0;
    while(j < 2000){
        initialize_distributed_voltage();
        j++;
    }

	voltage_model_init = 1;
    return;
}
/***********************************************************/
void compute_voltage (double * power_t, double * voltage_t) {
	int j;

	if (!voltage_model_init)  {
		init_distributed_voltage_model();
	}

	voltage_sim_cycle ++;

	/****** voltage calculation ******/
	calculate_distributed_voltage(power_t, voltage_t);


	// IR drop offset
	unsigned index;
	for (index = 0; index < number_of_components_t; index ++ ) {
		//voltage_t[index] += ( voltage_t[index+number_of_components_t] - voltage_t[index] );
		voltage_t[index] += 0;
	}
#if 0
	unsigned index;
	for (index = 0; index < 24; index ++ ) {
		if ( index < 8 )
			voltage_t[index] += power_t[index] * core_grid_r_value;
		else if ( index < 15 )
			voltage_t[index] += power_t[index] * non_core_grid_r_value;
		else if ( index < 23 )
			voltage_t[index] += power_t[index] * core_grid_r_value;
	}
#endif
}
