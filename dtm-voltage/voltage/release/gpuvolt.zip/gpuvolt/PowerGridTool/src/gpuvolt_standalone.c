
/**********************************************************************************************************
   This is an example of a distributed grid voltage simulation. 

   The main function of interest is calculate_distributed_voltage(), which
   populates the array voltage with the voltage for each core. This function is
   implemented in cktsolver_utils.c


  Input : cktfile describing the RLC connections of the grid (../cktfiles/date07_12x12.ckt)
        : a mapfile of the floorplan of the chip under consideration (../mapfiles/cmp.cores4.12x12.map)

  Output: voltages for each component described in the mapfile     

**********************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include "gzip_util.h"
#include "interface_voltage.h"
#define MAX_POWER 100

#define STEP 0
#define RAND 1
#define LUMPED_TEST 2
#define EXT_INPUT 3


unsigned simulation_type;
void voltage_simulation();
FILE * user_input = NULL;
extern unsigned number_of_components_t;
int number_of_cores;

int dump_power = 0;


int main(int argc,char *argv[]){

	unsigned i;
	if ( argc != 2) {
		fprintf(stderr, "Please specify the input file!\n");
		exit(1);
	}
	simulation_type = 3;
	number_of_components_t = 24;
	user_input = fopen(argv[1], "r");

    voltage_simulation();

    return 0;

}

/*********************************************************************************
  This function performs the voltage simulation.
  Currrently this is generating Power values for the cores and feeding it
  to the distribtued grid which returns the voltage for each of the core. This
  function uses two modes, either a step function, where each core has the same
  power. The second mode possible is a random power distribution. 

  This function can be easily incorporated with any simulator (simplescalar with
  support for power with Wattch). In such a scenario, the power numbers will be
  fed by the simulator and this function will provide the voltage of each block
  of interest. The Mapfile will need to be changed appropriately to reflect the
  correct floorplan and its mapping to the power-grid.

  This function should be modified to read from a file with the power numbers of
  the components being studied.


**********************************************************************************/
void voltage_simulation()
{

	number_of_cores=24;

	double * power = (double *)malloc(2*number_of_cores*sizeof(double));
    double * voltage = (double *)malloc(2*number_of_cores*sizeof(double));
    unsigned long long int sim_cycle=0;
    int j;
    char filename[512];
	FILE *power_fp;
	FILE *voltage_fp;

    srand(number_of_cores);
    filename[0]='\0';
    sprintf(filename,"power.cores%d.out",number_of_cores);
    power_fp=fopen(filename,"w");
    assert(power_fp!=NULL);

    filename[0]='\0';
    sprintf(filename,"voltage.cores%d.out",number_of_cores);
    voltage_fp=fopen(filename,"w");
    assert(voltage_fp!=NULL);

	double sin_tmp = 0; 
#if 0
    while(sim_cycle < 2000){
        sim_cycle++;
        for(j=0;j<number_of_cores;j++){
            switch(simulation_type){
              case STEP:
                if(sim_cycle>100){
                    power[j]=((double )MAX_POWER)/number_of_cores;
                }
                else{
                    power[j]=0;
                }
                break;
              case RAND:
                power[j]=rand() % (MAX_POWER/number_of_cores);
                break;
			  case LUMPED_TEST:
                power[j]= sin_tmp * (MAX_POWER/number_of_cores);
			  	break;
			  case EXT_INPUT:
			    break;
            }

            fprintf(power_fp,"%f\t",power[j]);
        }
#endif
	char input_line[2048];
	while ( fgets(input_line, 2047, user_input) != NULL ) {
		unsigned index = 0;
		char * tmp_str = input_line;
		char float_str[20];
		float non_core_power = 0;
		for (index = 0; index < 18; index ++ ) {
			char * result = tmp_str;
			char * tmp;
			unsigned i = 0;
			while ( *result != ',')  {
				float_str[i] = *result;
				result ++;
				i ++;
			}
			float_str[i]='\0';
			tmp_str = result + 1;
			double power_tmp = atof(float_str);
			if ( index < 8 )
				power[index] = power_tmp;
			else if ( index < 15 )
				power[index+8] = power_tmp;
			else 
				non_core_power += power_tmp;
		}
		non_core_power /= 3.0f;

		for ( unsigned j = 8; j < 16; j++)
			power[j] = non_core_power/(double)(8);

		if (dump_power) {
			for (unsigned j = 0; j< number_of_cores; j++ ) {
				fprintf(power_fp,"%.4f\t",power[j]);
			}
			fprintf(power_fp,"\n");
		}

		for (unsigned j = number_of_cores; j< 2*number_of_cores; j++ ) {
			power[j] = 0;
		}



        // adjust for the ir_offset
        compute_voltage(power, voltage);

        for(j=0;j<number_of_cores;j++){
            fprintf(voltage_fp,"%.4f\t",voltage[j]);
        }
        fprintf(voltage_fp,"\n");
    }

    fclose(power_fp);
    fclose(voltage_fp);
}
