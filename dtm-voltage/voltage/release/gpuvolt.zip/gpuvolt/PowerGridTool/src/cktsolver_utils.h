
/*---Function Prototypes -- */
void calculate_distributed_voltage(double *power_array, double *);
void  initialize_distributed_voltage();
void  find_voltage_per_block(double * voltage_array);
