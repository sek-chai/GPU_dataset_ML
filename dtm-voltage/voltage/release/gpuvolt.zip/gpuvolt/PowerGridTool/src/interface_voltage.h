#ifndef _INTERFACE_VOLTAGE_H
#define _INTERFACE_VOLTAGE_H
//extern "C" {
	void init_voltage_model();
	void compute_voltage (double * power_t, double *);
	void init_distributed_voltage_model_with_arg (unsigned ratio);
//}
#endif
