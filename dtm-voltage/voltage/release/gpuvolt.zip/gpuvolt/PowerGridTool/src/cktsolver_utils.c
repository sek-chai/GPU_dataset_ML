/*********************************************
 **********************************************

Description: Compute the voltage using the distributed model
             Also integrates Hotspot to get temperature measurements

Developed by:  Meeta Sharma Gupta
Last Update: Jan 12 2009

 *********************************************
 ********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include <time.h>

#include <sys/stat.h>
#include <sys/types.h>
#include "gzip_util.h"
#include "ckt.h"
#include "general_defs.h"


#define ABS(a) (((a)>0)?(a):-(a))
#define MAX(a,b) (((a)>(b))?(a):(b))
#define MIN(a,b) (((a)<(b))?(a):(b))

#define MAX_SIZE 512
#define true 1
//#define CKT_STEP 1/(3e9)

#define MAX_CORES 32

int max_ports=0,min_ports=1000;


/*------ EXTERN Variables ------*/
extern comp_str *component_array;
extern int number_of_components;
extern ckt_t *my_ckt;


extern double * node_voltage;
extern int number_of_points_per_core;
extern int number_of_cores;


/*---------------------------------------------------------------------- 
  track the voltage distribution of the component
  the min voltage of the component is the representative voltage 
  
  -If we are tracking at core-levels, then this translates to voltage per core
----- ---------------------------------------------------------------- */
void  find_voltage_per_block(double * voltage_array){

    double max_v,min_v;
    component_t *tmp_component;
    int i;

	if (number_of_components == (2*number_of_cores+1) ) {
		tmp_component = ckt_match_component(my_ckt,component_array[number_of_components-1].name ); // the last one is for package ir drop
		ckt_comp_extreme_no_error(my_ckt, tmp_component, &min_v, &max_v, &node_voltage[number_of_cores*number_of_points_per_core]);
		double pkg_ir_drop = min_v;
		for(i=0;i<number_of_cores;i++){
			assert(my_ckt!=NULL);
			tmp_component = ckt_match_component(my_ckt,component_array[i].name );
			component_t *tmp_component2 = ckt_match_component(my_ckt,component_array[i+number_of_cores].name);
			ckt_comp_extreme_with_ir_drop(my_ckt, tmp_component, &min_v, &max_v, &node_voltage[i*number_of_points_per_core], tmp_component2);
			voltage_array[i]=(min_v+pkg_ir_drop*2);
		}

	} else {

		for(i=0;i<number_of_components;i++){
			assert(my_ckt!=NULL);
			tmp_component = ckt_match_component(my_ckt,component_array[i].name );
			if (number_of_components >= 2*number_of_cores && i < number_of_cores ) {
				component_t *tmp_component2 = ckt_match_component(my_ckt,component_array[i+number_of_cores].name);
				ckt_comp_extreme_with_ir_drop(my_ckt, tmp_component, &min_v, &max_v, &node_voltage[i*number_of_points_per_core], tmp_component2);
			} else {
				ckt_comp_extreme(my_ckt, tmp_component, &min_v, &max_v, &node_voltage[i*number_of_points_per_core]);
			}
			voltage_array[i]=min_v;
		}

	}

}
/*--------------------------------------------------------------------- */


void  initialize_distributed_voltage(){

    component_t *tmp_component;
    int j;
    int total_number_ports=0;

    total_number_ports=0;
    for(j=0;j<number_of_components;j++){
        tmp_component = ckt_match_component(my_ckt,component_array[j].name);
        total_number_ports=total_number_ports+tmp_component->n_pos_port;
    }


    for(j=0;j<number_of_components;j++){
        tmp_component = ckt_match_component(my_ckt,component_array[j].name);
        component_set_load(tmp_component,(0*tmp_component->n_pos_port)/total_number_ports);
    }

    ckt_stepsolve_component(my_ckt);

    return ;
}

/*------------------------------------------------------------ */
void  calculate_distributed_voltage(double *power_array, double *voltage_array){

    component_t *tmp_component;
    int j;
    double value=0.0;
    int total_number_ports=0;



    total_number_ports=0;
    //DEBUG:fprintf(stdout,"%lf\n",power_array[IFU]);

    for(j=0;j<number_of_components;j++){
        tmp_component = ckt_match_component(my_ckt,component_array[j].name);

        // can adjust according to the map file, if we want to monitor the power
        // unit by unit or core by core
#if 0
       if(strncmp("falu",component_array[j+number_of_components*i].name,length-1)==0){
            value=(power_array[FALU]);
        }
#endif

        value=power_array[j];
        component_set_load(tmp_component,value);
    }



    ckt_stepsolve_component(my_ckt);


    find_voltage_per_block(voltage_array);


}

/*----------------------------------------------------------------------*/
