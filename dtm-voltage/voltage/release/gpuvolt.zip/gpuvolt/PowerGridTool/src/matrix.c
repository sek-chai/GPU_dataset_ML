#include <math.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "matrix.h"

long long flop_count;


matrix_t* matrix_new(int rows, int cols)
{
    int row_index;
    char *next_row_data;

    matrix_t *new_matrix = 
	malloc(sizeof(matrix_t) + sizeof(double*) * (rows*sizeof(double)) +
	       sizeof(double) * (rows*cols*sizeof(double)));

    new_matrix->n_rows = rows;
    new_matrix->n_cols = cols;
    new_matrix->data = (double**) (((char*)new_matrix) + sizeof(matrix_t));

    next_row_data = ((char*)new_matrix->data) + sizeof(double*) * rows;
    
    for(row_index = 0; row_index < rows; row_index++) {
	new_matrix->data[row_index] = (double*) next_row_data;
	next_row_data += sizeof(double) * cols;
    }

    return new_matrix;
}

void matrix_zero(matrix_t* mat)
{
    int row_index, col_index;

    for(row_index = 0; row_index < mat->n_rows; row_index++) 
	for(col_index = 0; col_index < mat->n_cols; col_index++) 
	    mat->data[row_index][col_index] = 0.0;
}

void matrix_set_row(matrix_t *mat, int row, double *values, int len)
{
    int index;

    assert(row >= 0 && row < mat->n_rows);
    assert(len == mat->n_cols);

    for(index = 0; index < mat->n_cols; index++) 
	mat->data[row][index] = values[index];
}

void matrix_set_col(matrix_t *mat, int col, double *values, int len)
{
    int index;

    assert(col >= 0 && col < mat->n_cols);
    assert(len == mat->n_rows);

    for(index = 0; index < mat->n_cols; index++) 
	mat->data[index][col] = values[index];
}

void matrix_set_data(matrix_t *mat, double *values, int len)
{
    int val_index = 0, row_index, col_index;

    assert(len == mat->n_rows * mat->n_cols);

    for(row_index = 0; row_index < mat->n_rows; row_index++)
	for(col_index = 0; col_index < mat->n_cols; col_index++) {
	    mat->data[row_index][col_index] = values[val_index];
	    val_index++;
	}
}

void matrix_copy(matrix_t *mat_b, matrix_t *mat_a)
{
    int row_index, col_index;

    assert(mat_a->n_rows == mat_b->n_rows);
    assert(mat_b->n_cols == mat_b->n_cols);

    for(row_index = 0; row_index < mat_a->n_rows; row_index++) 
	for(col_index = 0; col_index < mat_a->n_cols; col_index++) 
	    mat_b->data[row_index][col_index] = 
		mat_a->data[row_index][col_index];
}

void matrix_free(matrix_t* mat)
{
    free(mat);
}

void matrix_dump(FILE *outfile, matrix_t* mat)
{
    int row_index, col_index;

    for(row_index = 0; row_index < mat->n_rows; row_index++) {
	for(col_index = 0; col_index < mat->n_cols; col_index++) {
	    if (mat->data[row_index][col_index] >= 0.0)
		fprintf(outfile, " %0.4e ", mat->data[row_index][col_index]);
	    else
		fprintf(outfile, "%0.4e ", mat->data[row_index][col_index]);

	}
	fprintf(outfile, "\n");
    }
}

void matrix_set_element(matrix_t *mat, int row, int col, double val)
{
    mat->data[row][col] = val;
}

void matrix_superpos(matrix_t *mat_c,
		     double k_a, matrix_t *mat_a, 
		     double k_b, matrix_t *mat_b)
{
    int row_index, col_index;

    assert(mat_a->n_rows == mat_b->n_rows && mat_c->n_rows == mat_a->n_rows);
    assert(mat_b->n_cols == mat_b->n_cols && mat_c->n_cols == mat_a->n_cols);

    for(row_index = 0; row_index < mat_a->n_rows; row_index++)
	for(col_index = 0; col_index < mat_a->n_cols; col_index++)
	    mat_c->data[row_index][col_index] = 
		k_a * mat_a->data[row_index][col_index] +
		k_b * mat_b->data[row_index][col_index];
}

void matrix_add_element(matrix_t *mat, int row, int col, double k)
{
    assert(row >= 0 && row < mat->n_rows);
    assert(col >= 0 && col < mat->n_cols);

    mat->data[row][col] += k;
}

double matrix_element(matrix_t *mat, int row, int col)
{
    assert(row >= 0 && row < mat->n_rows);
    assert(col >= 0 && col < mat->n_cols);

    return mat->data[row][col];
}

void matrix_add(matrix_t *mat_c, matrix_t *mat_a, matrix_t *mat_b)
{
    matrix_superpos(mat_c, 1.0, mat_a, 1.0, mat_b);
}


void matrix_sub(matrix_t *mat_c, matrix_t *mat_a, matrix_t *mat_b)
{
    matrix_superpos(mat_c, 1.0, mat_a, -1.0, mat_b);
}

void matrix_scale(matrix_t *mat_b, double k_a, matrix_t *mat_a)
{
    int row_index, col_index;

    for(row_index = 0; row_index < mat_a->n_rows; row_index++)
	for(col_index = 0; col_index < mat_a->n_cols; col_index++)
	    mat_b->data[row_index][col_index] = 
		k_a * mat_a->data[row_index][col_index];
}

void matrix_mult(matrix_t *mat_c, matrix_t *mat_a, matrix_t *mat_b)
{
    int row_index, col_index, prod_index;

    assert(mat_a->n_cols == mat_b->n_rows);
    assert(mat_a->n_rows == mat_c->n_rows && mat_b->n_cols == mat_c->n_cols);
    
    for(row_index = 0; row_index < mat_a->n_rows; row_index++)
	for(col_index = 0; col_index < mat_b->n_cols; col_index++) {
	    mat_c->data[row_index][col_index] = 0;
	    for(prod_index = 0; prod_index < mat_a->n_cols; prod_index++)
		mat_c->data[row_index][col_index] +=
		    mat_a->data[row_index][prod_index] *
		    mat_b->data[prod_index][col_index];
	}
}

#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;}

void matrix_inv(matrix_t *mat_b, matrix_t *mat_a)
/* Linear equation solution by Gauss-Jordan elimination, equation (2.1.1) 
   above. a[1..n][1..n] is the input matrix. b[1..n][1..m] is input 
   containing the m right-hand side vectors. On output, a is 
   replaced by its matrix inverse, and b is replaced by the corresponding 
   set of solution vectors. */
{ 
    int *indxc,*indxr,*ipiv; 
    int i,icol,irow,j,k,l,ll; 
    double big,dum,pivinv,temp; 

    assert(mat_a->n_rows == mat_a->n_cols);
    assert(mat_a->n_rows == mat_b->n_rows);
    assert(mat_b->n_cols == mat_b->n_cols);

    matrix_copy(mat_b, mat_a);

    /* The integer arrays ipiv, indxr, and indxc are used for 
       bookkeeping on the pivoting. */

    indxc=malloc(sizeof(int) * mat_b->n_rows);
    indxr=malloc(sizeof(int) * mat_b->n_rows);
    ipiv=malloc(sizeof(int) * mat_b->n_rows);

    for (j=0;j<mat_b->n_rows;j++) 
	ipiv[j]=-1; 

    for (i=0;i<mat_b->n_rows;i++) { 
	/* This is the main loop over the columns to be reduced. */
	big=0.0; 
	for (j=0;j<mat_b->n_rows;j++) 
	    /* This is the outer loop of the search for a pivot element. */
	    if (ipiv[j] != 0) 
		for (k=0;k<mat_b->n_rows;k++) { 
		    if (ipiv[k] == -1) { 
			if (fabs(mat_b->data[j][k]) >= big) { 
			    big=fabs(mat_b->data[j][k]); 
			    irow=j; icol=k; 
			} 
		    } 
		} 
	++(ipiv[icol]); 
	/* We now have the pivot element, so we interchange rows, 
	   if needed, to put the pivot element on the diagonal. 
	   The columns are not physically interchanged, only relabeled: 
	   indxc[i], the column of the ith pivot element, 
	   is the ith column that is reduced, while indxr[i] is the 
	   row in which that pivot element was originally located. If 
	   indxr[i]  = indxc[i] there is an implied column interchange. 
	   With this form of bookkeeping, the solution b s will end up in 
	   the correct order, and the inverse matrix will be scrambled by 
	   columns. */
	if (irow != icol) { 
	    for (l=0;l<mat_b->n_rows;l++) 
		SWAP(mat_b->data[irow][l],mat_b->data[icol][l]);
	} 
	indxr[i]=irow; 

	/* We are now ready to divide the pivot row by the pivot element, 
	   located at irow and icol. */
	indxc[i]=icol; 
	if (mat_b->data[icol][icol] == 0.0) {
	    fprintf(stderr, "gaussj: Singular Matrix\n"); 
	    exit(-1);
	}
	pivinv=1.0/mat_b->data[icol][icol]; 
	mat_b->data[icol][icol]=1.0; 
	for (l=0;l<mat_b->n_rows;l++) 
	    mat_b->data[icol][l] *= pivinv; 
	for (ll=0;ll<mat_b->n_rows;ll++) 
	    /* Next, we reduce the rows... */
	    if (ll != icol) { 
		/* ...except for the pivot one, of course. */
		dum=mat_b->data[ll][icol]; 
		mat_b->data[ll][icol]=0.0; 
		for (l=0;l<mat_b->n_rows;l++) 
		    mat_b->data[ll][l] -= mat_b->data[icol][l]*dum; 
	    } 
    } 
    /* This is the end of the main loop over columns of the reduction. 
       It only remains to unscramble the solution in view of the column 
       interchanges. We do this by interchanging pairs of columns in the 
       reverse order that the permutation was built up. */
    for (l=mat_b->n_rows-1;l>=0;l--) { 
	if (indxr[l] != indxc[l]) 
	    for (k=0;k<mat_b->n_rows;k++) 
		SWAP(mat_b->data[k][indxr[l]],mat_b->data[k][indxc[l]]); 
    } 
    /* And we are done. */
    free(ipiv); 
    free(indxr); 
    free(indxc); 
}

#define TINY 1e-15

void ludcmp(double **a, int n, int *indx, double *d) 
/* Given a matrix a[1..n][1..n], this routine replaces it by the LU 
   decomposition of a rowwise permutation of itself. a and n are input. 
   a is output, arranged as in equation (2.3.14) above; indx[1..n] is an 
   output vector that records the row permutation effected by the partial 
   pivoting; d is output as ±1 depending on whether the number of row 
   interchanges was even or odd, respectively. This routine is used in 
   combination with lubksb to solve linear equations or invert a matrix.
*/
{
    int i,imax,j,k; 
    double big,dum,sum,temp; 
    double *vv; 

    /* vv stores the implicit scaling of each row.*/
    vv=malloc(sizeof(double)*n);
    *d=1.0; 
    /* No row interchanges yet.*/
    for (i=1;i<=n;i++) { 
	/* Loop over rows to get the implicit scaling information. */
	big=0.0; 
	for (j=1;j<=n;j++) 
	    if ((temp=fabs(a[i][j])) > big) 
		big=temp; 
	if (big == 0.0) 
	    fprintf(stderr,"Singular matrix in routine ludcmp"); 
	/* No nonzero largest element.*/ 
	vv[i]=1.0/big; 
	/* Save the scaling.*/ 
    } 
    for (j=1;j<=n;j++) { 
	/* This is the loop over columns of Crout s method. */
	for (i=1;i<j;i++) { 
	    /* This is equation (2.3.12) except for i = j. */
	    sum=a[i][j]; 
	    for (k=1;k<i;k++) 
		sum -= a[i][k]*a[k][j]; 
	    a[i][j]=sum; 
	} 
	big=0.0; 
	/* Initialize for the search for largest pivot element. */ 
	for (i=j;i<=n;i++) { 
	    /* This is i = j of equation (2.3.12) and i = j+1. . .N 
	       of equation (2.3.13). */
	    sum=a[i][j]; 
	    for (k=1;k<j;k++)
		sum -= a[i][k]*a[k][j]; 
	    a[i][j]=sum; 
	    if ( (dum=vv[i]*fabs(sum)) >= big) { 
		/* Is the  figure of merit for the pivot better than the 
		   best so far? */
		big=dum; 
		imax=i; 
	    } 
	} 
	if (j != imax) { 
	    /* Do we need to interchange rows? */
	    for (k=1;k<=n;k++) { 
		/* Yes, do so... */
		dum=a[imax][k]; 
		a[imax][k]=a[j][k]; 
		a[j][k]=dum; 
	    } 
	    *d = -(*d); 
            /* ...and change the parity of d. */
	    vv[imax]=vv[j]; 
	    /* Also interchange the scale factor. */ 
	} 
	indx[j]=imax; 
	if (a[j][j] == 0.0) { 
	    a[j][j]=TINY; 
	    fprintf(stderr,"Singular matrix in routine ludcmp"); 
	}
	/* If the pivot element is zero the matrix is singular 
	   (at least to the precision of the algorithm). For some 
	   applications on singular matrices, it is desirable to 
	   substitute TINY for zero. */
	if (j != n) { 
	    /* Now,  finnally, divide by the pivot element. */
	    dum=1.0/(a[j][j]); 
	    for (i=j+1;i<=n;i++) 
		a[i][j] *= dum; 
	} 
    } 
    /* Go back for the next column in the reduction. */
    free(vv);
}

void lubksb(double **a, int n, int *indx, double b[])
/* Solves the set of n linear equations A·X = B. Here a[1..n][1..n] is input, not
   as the matrix A but rather as its LU decomposition, determined by the routine
   ludcmp. indx[1..n] is input as the permutation vector returned by
   ludcmp. b[1..n] is input as the right-hand side vector B, and returns with the
   solution vector X. a, n, and indx are not modi ed by this routine and can be
   left in place for successive calls with different right-hand sides b. This
   routine takes into account the possibility that b will begin with many zero
   elements, so it is e cient for use in matrix inversion.
*/
{ 
    int i,ii=0,ip,j; 
    float sum; 
    for (i=1;i<=n;i++)     { 
	/* When ii is set to a positive value, it will become the index of the 
	   first nonvanishing element of b. We now do the forward substitution, 
	   equation (2.3.6). The only new wrinkle is to unscramble the 
	   permutation as we go. */
	ip=indx[i]; 
	sum=b[ip]; 
	b[ip]=b[i]; 
	if (ii) 
	    for (j=ii;j<=i-1;j++) 
		sum -= a[i][j]*b[j]; 
	else if (sum) 
	    ii=i; 
	/* A nonzero element was encountered, so from now on we will have to do 
	   the sums in the loop above. */

	b[i]=sum; 
    } 
    for (i=n;i>=1;i--) { 
	/* Now we do the backsubstitution, equation (2.3.7). */
	sum=b[i]; 
	for (j=i+1;j<=n;j++) 
	    sum -= a[i][j]*b[j]; 
	b[i]=sum/a[i][i]; 
	/* Store a component of the solution vector X. */
    }
    /* All done! */
}

void oldlucongrad(double **a, double **lu_a, int n, int *indx, double b[])
{
    double *x, *r, *v, *m;
    double k, l, p, c;
    int i,j,h;

    r = malloc(sizeof(double) * (1+n));
    v = malloc(sizeof(double) * (1+n));
    m = malloc(sizeof(double) * (1+n));
    x = malloc(sizeof(double) * (1+n));
    
    memcpy(x, b, sizeof(double) * (1+n));
    lubksb(lu_a, n, indx, x);

    for(i=1; i <= n; i++) {
	r[i] = b[i];
	for(j=1; j <= n; j++)
	    r[i] -= a[i][j] * x[j];
    }
    memcpy(v, r, sizeof(double) * (1+n));

    fprintf(stderr, "i: ");
    for(i=1; i <= n; i++)
	fprintf(stderr, "%e ", x[i]);
    fprintf(stderr, "\n");

    for(h=1; h <= n; h++)    {

	fprintf(stderr, "x_%d: ", h-1);
	for(i=1; i <= n; i++)
	    fprintf(stderr, "%e ", x[i]);
	fprintf(stderr, "\n");
	fprintf(stderr, "r_%d: ", h-1);
	for(i=1; i <= n; i++)
	    fprintf(stderr, "%e ", r[i]);
	fprintf(stderr, "\n");

	for(i=1; i <= n; i++) {
	    m[i] = 0.0;
	    for(j=1; j <= n; j++)
		m[i] += a[i][j] * v[j];
	}

	fprintf(stderr, "m_%d: ", h);
	for(i=1; i <= n; i++)
	    fprintf(stderr, "%e ", m[i]);
	fprintf(stderr, "\n");

	l = 0.0;
	p = 0.0;
	for(i=1; i <= n; i++) {
	    l += v[i] * r[i];
	    p += v[i] * m[i];
	}
	k = l / p;

	fprintf(stderr, "k_%d = %e  (%e)(%e)\n", h, k, l, p);

	for(i=1; i <= n; i++) {
	    x[i] += k * v[i];
	    r[i] -= k * m[i];
	}
	
	c = 0.0;
	for(i=1; i <= n; i++) {
	    for(j=1; j <= n; j++) 
		c -= v[i] * a[i][j] * r[j];
	}
	c = c / p;

	for(i=1; i <= n; i++)
	    v[i] = r[i] + c * v[i];

    }

    fprintf(stderr, "f: ");
    for(i=1; i <= n; i++)
	fprintf(stderr, "%e ", x[i]);
    fprintf(stderr, "\n\n");

    memcpy(b, x, sizeof(double) * (1+n));

    free(r);
    free(v);
    free(m);
    free(x);
}

void lucongrad(double **a, double **lu_a, int n, int *indx, double b[])
{
    double *x, *m, *v, *d;
    double alpha, alpha_num, alpha_den; 
    double beta, beta_num, beta_den; 
    double norm;
    
    int i, j, k;

    x = malloc(sizeof(double)*(1+n));
    m = malloc(sizeof(double)*(1+n));
    v = malloc(sizeof(double)*(1+n));
    d = malloc(sizeof(double)*(1+n));

    memcpy(x, b, sizeof(double)*(1+n));
    lubksb(lu_a, n, indx, x);    

    for(i=1; i<=n; i++) {
	d[i] = b[i];
	for(j=1; j<=n; j++) 
	    d[i] -= a[i][j] * x[j];
    }

    for(i=1; i<=n; i++) {
	v[i] = -b[i];
	for(j=1; j<=n; j++) 
	    v[i] += a[i][j] * x[j];
    }

    k = 0;
    do {

	for(i=1; i<=n; i++) {
	    m[i] = 0.0;
	    for(j=1; j<=n; j++) {
		m[i] += a[i][j] * d[j];
	    }
	}

	alpha_num = 0.0;
	alpha_den = 0.0;
	for(i=1; i<=n; i++) {
	    alpha_num += v[i] * d[i];
	    alpha_den += m[i] * d[i]; 
	}
	alpha = -alpha_num / alpha_den;

	for(i=1; i<=n; i++) 
	    x[i] += alpha * d[i];


	for(i=1; i<=n; i++) {
	    v[i] = -b[i];
	    for(j=1; j<=n; j++) 
		v[i] += a[i][j] * x[j];
	}

	beta_num = 0.0;
	for(i=1; i<=n; i++) 
	    beta_num += v[i] * m[i];
	beta_den = alpha_den;

	beta = beta_num / alpha_den;

	fprintf(stdout, "k = %d\n", k);
	fprintf(stdout, "\talpha = %e\n", alpha);
	fprintf(stdout, "\tbeta = %e\n", beta);
	fprintf(stdout, "\tx = [");
	for(i=1; i<=n; i++)
	    fprintf(stdout, "%e ", x[i]);
	fprintf(stdout, "]\n\n");

	norm = 0.0;
	for(i=1; i<=n; i++) {
	    d[i] = beta * d[i] - v[i];
	    norm += d[i] * d[i];
	}

	k++;
    }
    while(norm > 1e-8 && k < 2*n);

    memcpy(b, x, sizeof(double)*(1+n));
}


mat_t* mat_new(int rows, int cols)
{
    mat_t *new_mat = malloc(sizeof(mat_t));

    new_mat->n_row = rows;
    new_mat->n_col = cols;
    new_mat->n_melem = 0;
    
    new_mat->rows = calloc(sizeof(melem_t*), rows);

    return new_mat;
}

void mat_zero(mat_t *mat)
{
    int i;

    for(i=0; i < mat->n_row; i++) {
      melem_t *current = mat->rows[i];

      while(current) {
        melem_t *next = current->next;
        free(current);
        current = next;
      }
      mat->rows[i] = NULL;
    }
    mat->n_melem = 0;
}

double mat_get_element(mat_t *mat, int i, int j)
{
    melem_t *current = mat->rows[i-1];

    while (current && current->index <= j) {
	if (current->index < j)
	    current = current->next;
	else if (current->index == j)
	    return current->value;
    }
    return 0.0;
}

static void mat_update_element(mat_t *mat, int i, int j, 
			       int add, double value)
{
    melem_t *last =  NULL, *new_melem; 
    melem_t *current = mat->rows[i-1];

    while (current && current->index <= j) {
	last = current;
	if (current->index < j)
	    current = current->next;
	else {
	    if (add)
		current->value += value;
	    else 
		current->value = value;
	    return;
	}
    }

    new_melem = malloc(sizeof(melem_t));
    new_melem->next = current;
    new_melem->index = j;
    new_melem->value = value;
    mat->n_melem++;

    if (last)
	last->next = new_melem;
    else 
	mat->rows[i-1] = new_melem;
}

void mat_set_element(mat_t *mat, int i, int j, double value)
{
    mat_update_element(mat, i, j, 0, value);
}

void mat_add_element(mat_t *mat, int i, int j, double value)
{
    mat_update_element(mat, i, j, 1, value);
}


void mat_choldec(mat_t *mat, mat_t *chol)
{
    int i, j, k;

    mat_zero(chol);

    for(i = 1; i <= mat->n_row; i++) {
	for(j = i; j <= mat->n_row; j++) {
	    double sum = mat_get_element(mat, i, j);
	    melem_t *i_current = chol->rows[i-1];
	    melem_t *j_current = chol->rows[j-1];

	    for(k = 1; k <= i-1 && i_current && j_current; k++) {
		if (i_current->index == k &&
		    j_current->index == k)
		    sum -= i_current->value * j_current->value;

		if (i_current->index <= k)
		    i_current = i_current->next;

		if (j_current->index <= k)
		    j_current = j_current->next;
	    }

	    if (fabs(sum) > 0.0) {
		if (i == j)
		    mat_set_element(chol, i, i, sqrt(sum));
		else
		    mat_set_element(chol, j, i, sum / mat_get_element(chol, i,i));
	    }
	}
    }
}

double mat_diag(mat_t *mat)
{
    int i, j;
    double sum = 0.0;

    for(i=1; i <= mat->n_row; i++)
	for(j=1; j <= mat->n_row; j++)
	    sum += mat_get_element(mat, i, j);

    return sum / mat->n_row;
}

void mat_icholdec(mat_t *mat, mat_t *chol, double drop)
{
    int i, j, k;
    int non_zero = 0;
    double new_val;

    mat_zero(chol);

    for(i = 1; i <= mat->n_row; i++) {
	for(j = i; j <= mat->n_row; j++) {
	    double sum = mat_get_element(mat, i, j);
	    melem_t *i_current = chol->rows[i-1];
	    melem_t *j_current = chol->rows[j-1];

	    for(k = 1; k <= i-1 && i_current && j_current; k++) {
		if (i_current->index == k &&
		    j_current->index == k)
		    sum -= i_current->value * j_current->value;

		if (i_current->index <= k)
		    i_current = i_current->next;

		if (j_current->index <= k)
		    j_current = j_current->next;
	    }

	    if (i == j)
		new_val = sqrt(sum);
	    else
		new_val = sum / mat_get_element(chol, i, i);
	    
	    if (fabs(new_val) > drop || i == j) {
		mat_set_element(chol, j, i, new_val);
		non_zero++;
	    }
	}
    }

    fprintf(stderr, "non-zero: %d\n", non_zero);
}


void mat_cholsub(mat_t *chol, double *x, double *b)
{
    int i;
    static double *y, *d;
    static int block_size = 0;

    if (block_size == 0) {
	block_size = chol->n_row;
	y = malloc(sizeof(double)*(1+block_size));
	d = malloc(sizeof(double)*(1+block_size));
    }
    else if (block_size < chol->n_row)    {
	block_size = chol->n_row;
	y = realloc(y, sizeof(double)*(1+block_size));	
	d = realloc(d, sizeof(double)*(1+block_size));	
    }

    for(i=1; i<=chol->n_row; i++) {
	double sum = b[i];
	melem_t *current = chol->rows[i-1];

	while (current && current->index < i) {
	    sum -= current->value * y[current->index];
	    current = current->next;
	    flop_count += 2;
	}
	
	assert(current && current->index == i);
	d[i] = current->value;
	y[i] = sum / current->value;

	flop_count++;
    }

    memcpy(x, y, sizeof(double)*(1+chol->n_row));

    for(i=chol->n_row; i>=1; i--) {
	melem_t *current = chol->rows[i-1];

	x[i] = x[i] / d[i];

	current = chol->rows[i-1];
	while(current && current->index < i) {
	    x[current->index] -= current->value * x[i];
	    current = current->next;

	    flop_count += 2;
	}
    }
}



void mat_daxmy(mat_t *mat, double *x, double *b, double *y)
{
    int i;

    for(i = 0; i < mat->n_row; i++) {
	melem_t *current = mat->rows[i];

	if (b)
	    y[i+1] = -b[i+1];
	else
	    y[i+1] = 0.0;
	while(current) {
	    y[i+1] += x[current->index] * current->value;
	    current = current->next;
	}
    }

    flop_count += 3 * mat->n_row;
}

void mat_dump(FILE *outfile, mat_t *mat)
{
    int i;

    fprintf(outfile, "matrix has %d elements:\n", mat->n_melem);
    for(i = 0; i < mat->n_row; i++) {
	melem_t *current = mat->rows[i];

	while(current) {
	    fprintf(outfile, "\tmat[%d][%d] = %1.8e\n", i+1, 
		    current->index, current->value);
	    current = current->next;
	}
    }    
}

void dump_vect(char *name, double *v, int n)
{
    int i;

    fprintf(stderr, "%s = [", name);
    for(i = 1; i <= n; i++)
	fprintf(stderr, " %e", v[i]);

    fprintf(stderr, "]\n");
}

int mat_congrad(mat_t *A, mat_t *L, double *b, double *x, int n, double tol)
{
    double sigma_zero, sigma_new, sigma_old;
    double alpha_num, alpha_den, alpha;
    double beta;
    static double *r, *d, *q, *s;
    static int block_size = 0;
    int iter = 0, i;

    if (n == 0){
      printf("returning \n");
      return 0;
    }

    if (block_size == 0) {
	r = malloc(sizeof(double)*(1+n));
	s = malloc(sizeof(double)*(1+n));
	d = malloc(sizeof(double)*(1+n));
	q = malloc(sizeof(double)*(1+n));
	block_size = n;
    }
    else if (block_size != n) {
	r = realloc(r, sizeof(double)*(1+n));
	s = realloc(s, sizeof(double)*(1+n));
	d = realloc(d, sizeof(double)*(1+n));
	q = realloc(q, sizeof(double)*(1+n));
    }

    mat_daxmy(A, x, b, r);
    for(i=1; i<=n; i++)
	r[i] = -r[i];

    mat_cholsub(L, d, r);

    sigma_new = 0.0;
    for(i=1; i<=n; i++)
	sigma_new += r[i] * d[i];
    sigma_zero = sigma_new;

    flop_count += 2 * n;

    while (iter < n && (sigma_new > tol)) {
	mat_daxmy(A, d, NULL, q);

	alpha_num = sigma_new;
	alpha_den = 0.0;
	for(i=1; i<=n; i++) 
	    alpha_den += d[i] * q[i];
	alpha = alpha_num / alpha_den;

	flop_count += 2 * n + 1;
	for(i=1; i<=n; i++) {
	    x[i] += alpha * d[i];
  //    fprintf(stderr,"matrix.c mat_congrad(): x[%d]=%lf\n",i,x[i]);
  }

	flop_count += 2 * n;

	if (iter & 0x40) {
	    mat_daxmy(A, x, b, r);
	    for(i=1; i<=n; i++) 
		r[i] = -r[i];
	}
	else {
	    for(i=1; i<=n; i++) 
		r[i] -= alpha * q[i];

	    flop_count += 2 * n;
	}

	mat_cholsub(L, s, r);

	sigma_old = sigma_new;
	sigma_new = 0.0;
	for(i=1; i<=n; i++) 
	    sigma_new += r[i] * s[i];

	beta = sigma_new / sigma_old;

	flop_count += 2 * n + 1;

	for(i=1; i<=n; i++) 
	    d[i] = s[i] + beta * d[i];
	
	flop_count += 2 * n;

	iter++;
    }

    if (sigma_new > 100)
      fprintf(stderr, "Failed to converge!!!\n");

#if 0
    fprintf(stderr, "converged in %d iterations\n", iter);
#endif

    return iter;
}
