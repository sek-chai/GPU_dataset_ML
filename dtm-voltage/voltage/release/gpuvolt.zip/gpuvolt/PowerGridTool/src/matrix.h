#ifndef MATRIX_H
#define MATRIX_H

#include <stdio.h>

typedef struct {
    int n_rows;
    int n_cols;
    double **data;
} matrix_t;

typedef struct melem_s {
    int index;
    double value;
    struct melem_s *next;
} melem_t;

typedef struct {
    int n_row, n_col;
    int n_melem;
    melem_t **rows;
} mat_t;

mat_t* mat_new(int rows, int cols);
void mat_zero(mat_t *mat);
double mat_get_element(mat_t *mat, int i, int j);
void mat_set_element(mat_t *mat, int i, int j, double value);
void mat_add_element(mat_t *mat, int i, int j, double value);

void mat_icholdec(mat_t *, mat_t *, double);
double mat_diag(mat_t *);

void mat_daxmy(mat_t *mat, double *x, double *b, double *y);

matrix_t* matrix_new(int rows, int cols);
void matrix_zero(matrix_t* mat);
void matrix_free(matrix_t* mat);
void matrix_dump(FILE *outfile, matrix_t* mat);
void matrix_set_element(matrix_t *mat, int row, int col, double val);
void matrix_superpos(matrix_t *mat_c, double k_a, matrix_t *mat_a, 
		     double k_b, matrix_t *mat_b);
void matrix_add(matrix_t *mat_c, matrix_t *mat_a, matrix_t *mat_b);
void matrix_sub(matrix_t *mat_c, matrix_t *mat_a, matrix_t *mat_b);
void matrix_add_element(matrix_t *mat, int row, int col, double k);
double matrix_element(matrix_t *mat, int row, int col);
void matrix_scale(matrix_t *mat_b, double k_a, matrix_t *mat_a);
void matrix_mult(matrix_t *mat_c, matrix_t *mat_a, matrix_t *mat_b);
int mat_congrad(mat_t *A, mat_t *L, double *b, double *x, int n, double tol);
#endif
