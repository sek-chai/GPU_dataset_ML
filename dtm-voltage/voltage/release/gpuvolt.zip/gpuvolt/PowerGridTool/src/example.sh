#!/bin/sh
../bin/distributed_grid_example -cktfile:ckt_file ../cktfiles/date07_12x12.ckt -cktfile:map_file ../mapfiles/cmp.cores4.12x12.map -simulation:rand
