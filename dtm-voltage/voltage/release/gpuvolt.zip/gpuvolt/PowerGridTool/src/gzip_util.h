
/*********************************************
**********************************************

  GZOPEN and BZOPEN

  Developed by:  Kim Hazelwood Cettei
  Last Update: April 24, 2003

*********************************************
********************************************/

#include <stdio.h>
#include <string.h>

FILE * bzopen(char *fname, char *type);
void bzclose(FILE *fd);
FILE * gzopen(char *fname, char *type);
void gzclose(FILE *fd);
char * mystrrchr(char *s, char c);

