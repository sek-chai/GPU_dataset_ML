#ifndef CKT_H
#define CKT_H

#include <stdio.h>
#include "matrix.h"

#define MAX_CKT_NAME 255
#define MAX_COMP_NAME 256

typedef enum {
    R_elem = 0,
    L_elem,
    C_elem,
    I_elem,
    V_elem,
    U_elem
} enum_elem;

typedef struct {
    enum_elem type;
    int n_pos;
    int n_neg;
    double e_val;
    double m_val;
    double s_val;
    double br_a;
    double br_i;
    double br_v;
} elem_t;

typedef struct node_map {
    int user_node;
    int actual_node;
    struct node_map *next;
} node_map_t;

typedef struct {
    char name[MAX_COMP_NAME];
    double load;
    int  n_pos_port;
    int  n_neg_port;
    int  *ports;
} component_t;

typedef struct {
    int fixed;
    double step;
    double tol;
    unsigned long long iter;
    char name[MAX_CKT_NAME];
    mat_t *sys_mat;
    mat_t *pre_mat;
    double *mat_scale;
    double *rhs;
    double *v_vec;
    node_map_t **actual_hash;
    node_map_t **user_hash;
    int n_elem;
    int n_node;
    int n_mem;
    int n_const;
    int n_comp;
    int s_elem;
    int s_mem;
    int s_const;
    int s_comp;
    elem_t **elems;
    elem_t **mems;
    elem_t **consts;
    component_t **comps;
} ckt_t;



/* Meeta: b */

typedef struct comp{
  char name[256];
  double peak_min;
  double peak_max;
  FILE *fp;
} comp_str;
/* Meeta: e */


elem_t* elem_new(enum_elem type, int n_pos, int n_neg, 
		 double value, double step);
void elem_dump(elem_t *elem, FILE *outfile);
ckt_t* ckt_new(char *name, double timestep);
ckt_t* ckt_read(char *name, FILE *infile, double timestep);
void ckt_add_branch(ckt_t *ckt, 
			   enum_elem type, int n_pos, int n_neg, double value);
void ckt_dump(ckt_t *ckt, FILE *outfile);
matrix_t* ckt_sysmat(ckt_t *ckt);

void ckt_eqn_step(matrix_t *v_now, matrix_t *A_inv,
		  matrix_t *u_now, matrix_t *i_now);
void ckt_stepsolve_comp(ckt_t *ckt); 
void ckt_stepsolve_mat(ckt_t *ckt, double *u, int reuse_rhs);
component_t* ckt_match_component(ckt_t *ckt, char *name);

double ckt_node_voltage(ckt_t*,int);

void ckt_reset_iter(ckt_t *ckt);
unsigned long long ckt_get_iter(ckt_t *ckt);
void ckt_set_tolerance(ckt_t *ckt, double);
void ckt_precond(ckt_t *ckt, double);
void  ckt_size(ckt_t *ckt, int *, int *, int *);
double ckt_diag(ckt_t *);

void component_set_load(component_t *comp, double load);
void ckt_comp_extreme_with_ir_drop(ckt_t *ckt, component_t *comp, double *min_voltage, double *max_voltage, double *node_v, component_t *comp2);
void ckt_comp_extreme(ckt_t *ckt, component_t *comp, double *min_voltage, double *max_voltage, double *node_v);
void ckt_comp_extreme_no_error(ckt_t *ckt, component_t *comp, double *min_voltage, double *max_voltage, double *node_v);
double ckt_comp_mean(ckt_t *ckt, component_t *comp);
void ckt_stepsolve_component(ckt_t *ckt);
void ckt_prepare(ckt_t *ckt);
void ckt_load_components(ckt_t *ckt, FILE *infile);

ckt_t* ckt_init(char *name, char *name2, double timestep);

#endif
