
/*********************************************
**********************************************

  GZOPEN and BZOPEN

  Developed by:  Kim Hazelwood Cettei
  Last Update: April 24, 2003

*********************************************
********************************************/

#include "gzip_util.h"

#define GZIP_PATH "/bin/gzip"
#define BZIP_PATH "/usr/bin/bzip2"
#define N_ELT(ARR)   (sizeof(ARR)/sizeof((ARR)[0]))


static struct {
  char *type;
  char *ext;
  char *cmd;
} bzcmds[] = {
  /* type */    /* extension */         /* command */
  { "r",        ".bz2",                  "%s -dc %s" },
  { "rb",       ".bz2",                  "%s -dc %s" },
  { "w",        ".bz2",                  "%s > %s" },
  { "wb",       ".bz2",                  "%s > %s" }
};

static struct {
  char *type;
  char *ext;
  char *cmd;
} gzcmds[] = {
  /* type */    /* extension */         /* command */
  { "r",        ".gz",                  "%s -dc %s" },
  { "rb",       ".gz",                  "%s -dc %s" },
  { "r",        ".Z",                   "%s -dc %s" },
  { "rb",       ".Z",                   "%s -dc %s" },
  { "w",        ".gz",                  "%s > %s" },
  { "wb",       ".gz",                  "%s > %s" }
};


FILE * gzopen(char *fname, char *type)
{
  int i;
  char *cmd = NULL, *ext;
  FILE *fd;
  char str[2048];

  /* get the extension */
  ext = mystrrchr(fname, '.');

  /* check if extension indicates compressed file */
  if (ext != NULL && *ext != '\0') {
      for (i=0; i < N_ELT(gzcmds); i++) {
          if (!strcmp(gzcmds[i].type, type) && !strcmp(gzcmds[i].ext, ext)) {
              cmd = gzcmds[i].cmd;
              break;
          }
      }
  }

  if (!cmd) {
      /* open file */
      fd = fopen(fname, type);
  }
  else {
      /* open pipe to compressor/decompressor */
      sprintf(str, cmd, GZIP_PATH, fname);
      fd = popen(str, type);
  }

  return fd;
}

FILE * bzopen(char *fname, char *type)
{
  int i;
  char *cmd = NULL, *ext;
  FILE *fd;
  char str[2048];

  /* get the extension */
  ext = mystrrchr(fname, '.');

  /* check if extension indicates compressed file */
  if (ext != NULL && *ext != '\0') {
      for (i=0; i < N_ELT(bzcmds); i++) {
          if (!strcmp(bzcmds[i].type, type) && !strcmp(bzcmds[i].ext, ext)) {
              cmd = bzcmds[i].cmd;
              break;
          }
      }
  }

  if (!cmd) {
      /* open file */
      fd = fopen(fname, type);
  }
  else {
      /* open pipe to compressor/decompressor */
      sprintf(str, cmd, BZIP_PATH, fname);
      fd = popen(str, type);
  }

  return fd;
}

/* close compressed stream */
void bzclose(FILE *fd)
{
  gzclose(fd); 
}

/* close compressed stream */
void gzclose(FILE *fd)
{
  /* attempt pipe close, otherwise file close */
  if (pclose(fd) == -1)
    fclose(fd);
}

/* find the last occurrence of a character in a string */
char * mystrrchr(char *s, char c)
{
  char *rtnval = 0;

  do {
    if (*s == c)
      rtnval = s;
  } while (*s++);

  return rtnval;
}

