#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>

#include "ckt.h"
#include "matrix.h"

#define SMALL_R 1e-9
#define SMALL_V 1e-9

#define MIN(a, b) ((a < b) ? a : b)
#define MAX(a, b) ((a > b) ? a : b)

/* Meeta: b */
#define MAX_COMPS 512 
comp_str *component_array;
int number_of_components=0;
/* Meeta : e */



char *elem_map = {"RLCIVU"};

void ckt_add_component_rhs(ckt_t *ckt);
elem_t* elem_new(enum_elem type, int n_pos, int n_neg, 
    double value, double step)
{
  elem_t *new_elem = malloc(sizeof(elem_t));

  new_elem->type = type;
  new_elem->n_pos = n_pos;
  new_elem->n_neg = n_neg;
  new_elem->br_i = 0.0;
  new_elem->br_a = 0.0;
  new_elem->br_v = 0.0;
  new_elem->e_val = value;

  switch (type) {
    case R_elem:
      new_elem->m_val = 1.0 / value;
      new_elem->s_val = 1.0 / value;
      break;
    case L_elem:
      new_elem->m_val = step / (2.0 * value);
      new_elem->s_val = 1.0 / SMALL_R; 
      break;
    case C_elem:
      new_elem->m_val = 2.0 * value / step;
      new_elem->s_val = 0.0; /* used to be SMALL_R  */
      break;
    case I_elem:
      new_elem->m_val = 0.0;
      new_elem->s_val = 0.0;
      new_elem->br_i = value;
      new_elem->br_a = value;
      break;
    case V_elem:
      new_elem->m_val = 1.0 / SMALL_R;
      new_elem->s_val = 1.0 / SMALL_R;
      new_elem->br_i = value / SMALL_R;
      new_elem->br_a = -value / SMALL_R;
      break;
    default:
      /* should panic here */
      new_elem->m_val = 0.0;
      new_elem->s_val = 0.0;
  }
  return new_elem;
}

void elem_dump(elem_t *elem, FILE *outfile)
{
  fprintf(outfile, "%c%10d%10d%10.4g",
      elem_map[elem->type],
      elem->n_pos,
      elem->n_neg,
      elem->e_val);
}

#define NODE_HASH_SIZE  1023

ckt_t* ckt_new(char *name, double timestep)
{
  ckt_t *new_ckt = malloc(sizeof(ckt_t));

  strncpy(new_ckt->name, name, MAX_CKT_NAME);
  new_ckt->fixed = 0;
  new_ckt->step = timestep;
  new_ckt->iter = 0;
  new_ckt->tol = 1e-10;
  new_ckt->n_node = 0;
  new_ckt->n_elem = 0;
  new_ckt->n_mem = 0;
  new_ckt->n_const = 0;
  new_ckt->s_elem = 64;
  new_ckt->s_mem = 64;
  new_ckt->s_const = 64;
  new_ckt->elems = malloc(sizeof(elem_t*) * new_ckt->s_elem);
  new_ckt->mems = malloc(sizeof(elem_t*) * new_ckt->s_mem);
  new_ckt->consts = malloc(sizeof(elem_t*) * new_ckt->s_const);

  new_ckt->user_hash = calloc(NODE_HASH_SIZE, sizeof(node_map_t*));
  new_ckt->actual_hash = calloc(NODE_HASH_SIZE, sizeof(node_map_t*));

  return new_ckt;
}

//static int index_node(ckt_t *ckt, int user_node)
int index_node(ckt_t *ckt, int user_node)
{
  node_map_t *current;
  int user_index = user_node % NODE_HASH_SIZE;

  if (user_node == 0)
    return 0;

  current = ckt->user_hash[user_index];
  while(current && current->user_node != user_node)
    current = current->next;

  if (current)
    return current->actual_node;
  else
    return 0;
}

static int actual_node(ckt_t *ckt, int user_node)
{
  node_map_t *current;
  int user_index = user_node % NODE_HASH_SIZE;
  int actual_index;

  if (user_node == 0)
    return 0;

  current = ckt->user_hash[user_index];
  while(current && current->user_node != user_node)
    current = current->next;

  if (!current) {
    assert(!ckt->fixed);

    ckt->n_node++;

    current = malloc(sizeof(node_map_t));
    current->user_node = user_node;
    current->actual_node = ckt->n_node;
    current->next = ckt->user_hash[user_index];
    ckt->user_hash[user_index] = current;

    actual_index = current->actual_node % NODE_HASH_SIZE;
    current = malloc(sizeof(node_map_t));
    current->user_node = user_node;
    current->actual_node = ckt->n_node;
    current->next = ckt->actual_hash[actual_index];
    ckt->actual_hash[actual_index] = current;
  }

  /*    fprintf(stderr, "%d -> %d\n", user_node, current->actual_node); */

  return current->actual_node;
}

static int user_node(ckt_t *ckt, int actual_node)
{
  node_map_t *current;
  int index = actual_node % NODE_HASH_SIZE;

  if (actual_node == 0)
    return 0;

  current = ckt->actual_hash[index];
  while(current && current->actual_node != actual_node)
    current = current->next;

  if (!current) {
    fprintf(stderr, "*** warning: unknown node %d ***\n", actual_node);
    return 0;
  }
  else
    return current->user_node;
}

static int read_spice_val(char *buffer, double *val)
{
  char buff_suffix[256], buff_upper[256];
  double plain_dbl, scale;
  int index, length = strlen(buffer);
  int nconv, success = 0;

  for(index = 0; index < length; index++)
    buff_upper[index] = toupper(buffer[index]);
  buff_upper[index] = '\0';

  nconv = sscanf(buff_upper, "%lf%s", &plain_dbl, buff_suffix);
  if (nconv == 1) {
    success = -1;
    scale = 1.0;
  }
  else if (nconv == 2) {
    success = -1;
    switch(toupper(buff_suffix[0])) {
      case 'T':
        scale = 1e12;
        break;
      case 'G':
        scale = 1e9;
        break;
      case 'M':
        if (!strncmp(buff_upper+index, "MEG", 3))
          scale = 1e6;
        else
          scale = 1e-3;
        break;
      case 'K':
        scale = 1e3;
        break;
      case 'U':
        scale = 1e-6;
        break;
      case 'N':
        scale = 1e-9;
        break;
      case 'P':
        scale = 1e-12;
        break;
      case 'F':
        scale = 1e-15;
        break;
      default:
        success = 0;
        scale = 1.0;
        break;
    }
  }

  if (success && val)
    *val = plain_dbl * scale;

  return success;
}

double ckt_node_voltage(ckt_t *ckt, int node)
{
  int index = index_node(ckt, node);

  if (index)
    return ckt->v_vec[index];
  else
    return 0.0;
}

/* Meeta */
ckt_t* ckt_init(char *name, char *name2, double timestep)
{
  ckt_t *my_ckt;
  FILE *cktfile, *mapfile;

  cktfile = fopen(name, "r");
  if (!cktfile) {
    fprintf(stderr, "ckt_init: could not open file \"%s\"\n", name);
    exit(-1);
  }

  // Open map file
  mapfile = fopen(name2, "r");
  if (!mapfile) {
    fprintf(stderr, "ckt_init: could not open file \"%s\"\n", name2);
    exit(-1);
  }

  my_ckt = ckt_read(name, cktfile, timestep);
  component_array=(comp_str *)malloc(sizeof(comp_str)*MAX_COMPS);
  ckt_load_components(my_ckt, mapfile);   

  ckt_prepare(my_ckt);
  fprintf(stderr,"Done preparing the cicruit \n");
  return my_ckt;
}
/* Meeta: e*/



ckt_t* ckt_read(char *name, FILE *infile, double timestep)
{
  ckt_t *new_ckt = ckt_new(name, timestep);
  int doneline, lineno = 1;
  char buffer[256];

  while (fgets(buffer, sizeof(buffer), infile)) {
    int elem_type;
    char elem_name[256], elem_val_str[256];
    int node_pos_int, node_neg_int;
    int nconv;
    double elem_val_dbl;

    doneline = 0;

    if (buffer[0])
      nconv = sscanf(buffer, "%s %d %d %s",
          elem_name, &node_pos_int, &node_neg_int,
          elem_val_str);
    else
      doneline = -1;

    if (!doneline && (nconv == -1 || elem_name[0] == '*')) 
      doneline = -1;
    else if (nconv == 4) {
      switch (elem_name[0]) {
        case '*':
          /* comment */
          doneline = -1;
          break;
        case 'R':
        case 'r':
          elem_type = R_elem;
          break;
        case 'L':
        case 'l':
          elem_type = L_elem;
          break;
        case 'C':
        case 'c':
          elem_type = C_elem;
          break;
        case 'V':
        case 'v':
          elem_type = V_elem;
          break;
        default:
          fprintf(stderr, "%s: unrecognized element type '%c' on line %d\n",
              name, elem_name[0], lineno);
          doneline = -1;
          break;
      }

      if (!doneline && (node_pos_int < 0 || node_neg_int < 0 ||
            node_pos_int == node_neg_int)) {
        fprintf(stderr, "%s: invalid node specification %d and %d on line %d\n", 
            name, node_pos_int, node_neg_int, lineno);
        doneline = -1;
      }

      if (!doneline && !read_spice_val(elem_val_str, &elem_val_dbl))
        fprintf(stderr, "%s: unrecognized format for value \"%s\" on line %d\n",
            name, elem_val_str, lineno);


      if (!doneline) {
        int renamed_pos, renamed_neg;

        renamed_pos =  actual_node(new_ckt, node_pos_int); 
        renamed_neg =  actual_node(new_ckt, node_neg_int); 
        ckt_add_branch(new_ckt, elem_type, 
            renamed_pos, renamed_neg,
            elem_val_dbl);
      }
    }
    else {
      fprintf(stderr, "invalid element description on line %d\n", 
          lineno);
    }

  }

  return new_ckt;
}

void ckt_add_branch(ckt_t *ckt, 
    enum_elem type, int n_pos, int n_neg, double value)
{
  elem_t *new_elem = elem_new(type, n_pos, n_neg, value, ckt->step);

  if (ckt->n_elem >= ckt->s_elem) {
    ckt->s_elem = ckt->s_elem * 2;
    ckt->elems = realloc(ckt->elems, ckt->s_elem * sizeof(elem_t*));
  }

  if (ckt->n_mem >= ckt->s_mem) {
    ckt->s_mem = ckt->s_mem * 2;
    ckt->mems = realloc(ckt->mems, ckt->s_mem * sizeof(elem_t*));
  }

  if (ckt->n_const >= ckt->s_const) {
    ckt->s_const = ckt->s_const * 2;
    ckt->consts = realloc(ckt->consts, ckt->s_const * sizeof(elem_t*));
  }

  ckt->elems[ckt->n_elem] = new_elem;
  ckt->n_elem++;

  if (new_elem->type == L_elem || new_elem->type == C_elem) {
    ckt->mems[ckt->n_mem] = new_elem;
    ckt->n_mem++;
  }

  if (new_elem->type == I_elem || new_elem->type == V_elem) {
    ckt->consts[ckt->n_const] = new_elem;
    ckt->n_const++;
  }

  if (new_elem->n_pos > ckt->n_node)
    ckt->n_node = new_elem->n_pos;

  if (new_elem->n_neg > ckt->n_node)
    ckt->n_node = new_elem->n_neg;
}

void ckt_dump(ckt_t *ckt, FILE *outfile)
{
  int index;

  fprintf(outfile, "Circuit Name: %s\n", ckt->name);
  fprintf(outfile, "All elements:\n");
  for(index = 0; index < ckt->n_elem; index++) {
    fputs("\t", outfile);
    elem_dump(ckt->elems[index], outfile);
    fputs("\n", outfile);
  }

  fprintf(outfile, "Memory elements:\n");
  for(index = 0; index < ckt->n_mem; index++) {
    fputs("\t", outfile);
    elem_dump(ckt->mems[index], outfile);
    fputs("\n", outfile);
  }
}

void ckt_mat(ckt_t *ckt, int use_ss)
{
  int index;

  mat_zero(ckt->sys_mat);

  for(index = 0; index < ckt->n_elem; index++) {
    elem_t *elem = ckt->elems[index];

    double ckt_val = (use_ss) ? elem->s_val : elem->m_val;

    if (elem->type != I_elem && elem->type != U_elem) {
      if (elem->n_pos && elem->n_neg) {
        mat_add_element(ckt->sys_mat, elem->n_pos, elem->n_pos, ckt_val);
        mat_add_element(ckt->sys_mat, elem->n_neg, elem->n_neg, ckt_val);
        mat_add_element(ckt->sys_mat, elem->n_pos, elem->n_neg, -ckt_val);
        mat_add_element(ckt->sys_mat, elem->n_neg, elem->n_pos, -ckt_val);
      }
      else if (!elem->n_pos)
        mat_add_element(ckt->sys_mat, elem->n_neg, elem->n_neg, ckt_val);

      else if (!elem->n_neg)
        mat_add_element(ckt->sys_mat, elem->n_pos, elem->n_pos, ckt_val);
    }
  }
}

void ckt_prepare(ckt_t *ckt)
{
  int index, i;
  double diag;

  ckt->fixed = -1;

  ckt->rhs = calloc(sizeof(double), (1+ckt->n_node));
  ckt->v_vec = calloc(sizeof(double), (1+ckt->n_node));

  ckt_add_component_rhs(ckt);

  for(index = 0; index < ckt->n_elem; index++) {
    elem_t *elem = ckt->elems[index];

    if (elem->n_pos)
      ckt->rhs[elem->n_pos] -= elem->br_a;

    if (elem->n_neg)
      ckt->rhs[elem->n_pos] += elem->br_a;
  }

  ckt->sys_mat = mat_new(ckt->n_node, ckt->n_node);

  ckt_mat(ckt, -1);

  ckt->pre_mat = mat_new(ckt->n_node, ckt->n_node);
  mat_icholdec(ckt->sys_mat, ckt->pre_mat, 0.0);

  mat_congrad(ckt->sys_mat, ckt->pre_mat,
      ckt->rhs, ckt->v_vec, ckt->n_node, ckt->tol);

  for(index = 0; index < ckt->n_elem; index++) {
    elem_t *elem = ckt->elems[index];
    double pos_v = 0.0, neg_v = 0.0;

    if (elem->n_pos) {
      pos_v = ckt->v_vec[elem->n_pos];
    }
    if (elem->n_neg) {
      neg_v = ckt->v_vec[elem->n_neg];
    }

    elem->br_v = pos_v - neg_v;

    if (fabs(elem->br_v) < SMALL_V)
      elem->br_v = 0.0;

    if (elem->type == C_elem) {
      elem->br_i = 0.0;
      elem->br_a = -elem->m_val * elem->br_v;
    }

    if (elem->type == L_elem) {
      elem->br_i = elem->br_v / SMALL_R;
      elem->br_a = elem->m_val * elem->br_v + elem->br_v / SMALL_R;
    }
  }

  ckt_mat(ckt, 0);

  diag = 1e-3 * mat_diag(ckt->sys_mat);
  fprintf(stderr, "diag_avg = %e\n", diag);
  mat_icholdec(ckt->sys_mat, ckt->pre_mat, diag);

  fprintf(stderr, "Cholesky has %d elements (compared to %d) in original\n",
      ckt->pre_mat->n_melem,  ckt->sys_mat->n_melem);

#if 0
  fprintf(stdout, "initial_state solution:\n");
  for(index = 1; index <= ckt->n_node; index++)
    fprintf(stdout, "v(%d) = %e\n", 
        user_node(ckt, index),
        ckt->v_vec[index]);
  fprintf(stderr, "\n");
#endif 

}

void component_set_load(component_t *comp, double load)
{
  comp->load = load;
}

component_t* ckt_match_component(ckt_t *ckt, char *name)
{
  int comp_index;

  assert(ckt!=NULL);

  for(comp_index = 0; comp_index < ckt->n_comp; comp_index++) {    
    if (!strcmp(ckt->comps[comp_index]->name, name))
      return ckt->comps[comp_index];
  }

  return NULL;
}

void ckt_add_component_rhs(ckt_t *ckt)
{
  int comp_index, node_index;
  int i;

  for(comp_index = 0; comp_index < ckt->n_comp; comp_index++) {
    double pos_scale, neg_scale;
    int pos_port, neg_port;

    pos_port = ckt->comps[comp_index]->n_pos_port;
    neg_port = ckt->comps[comp_index]->n_neg_port;

    if (pos_port)
      pos_scale = -1.0 / (double) pos_port;

    if (neg_port)
      neg_scale = 1.0 / (double) neg_port;

    for(node_index = 0; node_index < (pos_port+neg_port); node_index++) 
      if (ckt->comps[comp_index]->ports[node_index] > 0) {
        ckt->rhs[ckt->comps[comp_index]->ports[node_index]] +=
          pos_scale * ckt->comps[comp_index]->load;
      }
      else if (ckt->comps[comp_index]->ports[node_index] <= 0) {
        ckt->rhs[-ckt->comps[comp_index]->ports[node_index]] +=
          neg_scale * ckt->comps[comp_index]->load;
      }
  }
}

void ckt_stepsolve_component(ckt_t *ckt)
{
  int comp_index, node_index;
  int i;

  for(i = 1; i <= ckt->n_node; i++) 
    ckt->rhs[i] = 0.0;

  ckt_add_component_rhs(ckt);

  ckt_stepsolve_mat(ckt, NULL, -1);
}

void ckt_stepsolve_mat(ckt_t *ckt, double *u, int reuse_rhs)
{
  int index, i;

  if (!reuse_rhs) {
    if (u)
      for(i = 1; i <= ckt->n_node; i++)
        ckt->rhs[i] = u[i];
    else
      for(i = 1; i <= ckt->n_node; i++)
        ckt->rhs[i] = 0.0;
  }


  for(index = 0; index < ckt->n_elem; index++) {
    double pos_v = 0.0, neg_v = 0.0;
    double new_v;
    elem_t *elem = ckt->elems[index];

    if (elem->n_pos) {
      pos_v = ckt->v_vec[elem->n_pos];
    }
    if (elem->n_neg) {
      neg_v = ckt->v_vec[elem->n_neg];
    }

    new_v = pos_v - neg_v;

    if (elem->type == C_elem) {
      elem->br_i = elem->m_val * (new_v - elem->br_v) - elem->br_i;
      elem->br_v = new_v;
      elem->br_a = -elem->m_val * elem->br_v - elem->br_i;
    }

    if (elem->type == L_elem) {
      elem->br_i = elem->m_val * (new_v + elem->br_v) + elem->br_i;
      elem->br_v = new_v;
      elem->br_a = elem->m_val * elem->br_v + elem->br_i;
    }

    if (elem->type == V_elem) {
      elem->br_v = new_v;
      elem->br_a = -elem->m_val * elem->e_val;
    }

    if (elem->type == I_elem) {
      elem->br_v = new_v;
      elem->br_a = elem->e_val;
    }

    if (elem->type == R_elem) {
      elem->br_v = new_v;
    }
#if 0
    fprintf(stdout, "elems[%d]\ti=%e\tv=%e\ta=%e\n",
        index, elem->br_i, elem->br_v, elem->br_a);
#endif
  }

  for(index = 0; index < ckt->n_elem; index++) {
    elem_t *elem = ckt->elems[index];

    if (elem->n_pos)
      ckt->rhs[elem->n_pos] -= elem->br_a;

    if (elem->n_neg)
      ckt->rhs[elem->n_neg] += elem->br_a;
  }

#if 0
  fprintf(stdout, "rhs:\n");
  for(i = 1; i <= ckt->n_node; i++)
    fprintf(stdout, "%e\n", ckt->rhs[i]);
#endif

#if 0
  fprintf(stdout, "----\n");    
  matrix_dump(stdout, ckt->rhs);
#endif 

  ckt->iter += mat_congrad(ckt->sys_mat, ckt->pre_mat, 
      ckt->rhs, ckt->v_vec, ckt->n_node, ckt->tol);
}

static matrix_t* alloc_mat(matrix_t *mat, int rows, int cols)
{
  if (!mat || mat->n_rows != rows || mat->n_cols != cols)
  {
    if (mat)
      matrix_free(mat);

    mat = matrix_new(rows, cols);
  }	

  return mat;
}

static matrix_t *ui_sum;

void ckt_eqn_step(matrix_t *v_now, matrix_t *A_inv,
    matrix_t *u_now, matrix_t *i_now)
{
  ui_sum = alloc_mat(ui_sum, u_now->n_rows, u_now->n_cols);

  matrix_add(ui_sum, u_now, i_now);
  matrix_mult(v_now, A_inv, ui_sum);
}


void ckt_load_components(ckt_t *ckt, FILE *infile)
{
  char name[MAX_COMP_NAME];
  int *node_arr;
  int pos_node, neg_node, node_slots = 1024;


  ckt->n_comp = 0;
  ckt->s_comp = 64;
  ckt->comps = malloc(sizeof(int) * node_slots);

  node_arr = malloc(sizeof(int)*node_slots);

  while (fscanf(infile, "%s", name) > 0) {
    int new_node;
    component_t *new_comp;

    pos_node = 0;
    neg_node = 0;
    while (fscanf(infile, "%d", &new_node) > 0) {


      if (new_node > 0)	    {
        node_arr[pos_node+neg_node] = actual_node(ckt, abs(new_node));
        pos_node++;
      }
      else {
        node_arr[pos_node+neg_node] = -actual_node(ckt, abs(new_node));
        neg_node++;
      }

      if (node_slots == (pos_node + neg_node)) {
        node_slots = node_slots << 1;
        node_arr = realloc(node_arr, sizeof(int)*node_slots);
      }
    }

    new_comp = malloc(sizeof(component_t) + 
        sizeof(int)*(pos_node+neg_node));
    if (pos_node+neg_node)
      new_comp->ports = (int*) (((char*)new_comp) + sizeof(component_t));
    else 
      new_comp->ports = NULL;
    new_comp->n_pos_port = pos_node;
    new_comp->n_neg_port = neg_node;
    new_comp->load = 0.0;
    strcpy(new_comp->name, name);
    /* Meeta : b */
    strcpy(component_array[number_of_components].name,name);
    component_array[number_of_components].peak_max=0.0;
    component_array[number_of_components].peak_min=1000.0;

    number_of_components++;

    if(number_of_components >=MAX_COMPS){
      fprintf(stderr,"exceeded the number of components allowed \n");
      exit(-1);
    }

    /* Meeta : e */
    memcpy(new_comp->ports, node_arr, sizeof(int) * (pos_node+neg_node));

    ckt->comps[ckt->n_comp] = new_comp;	
    ckt->n_comp++;
  }
}

void ckt_reset_iter(ckt_t *ckt)
{
  ckt->iter = 0;
}

unsigned long long ckt_get_iter(ckt_t *ckt)
{
  return ckt->iter;
}

void ckt_set_tolerance(ckt_t *ckt, double tol)
{
  ckt->tol = tol;
}

void ckt_precond(ckt_t *ckt, double drop)
{
  mat_icholdec(ckt->sys_mat, ckt->pre_mat, drop);
}

void  ckt_size(ckt_t *ckt, int *node, int *elem, int *precond)
{
  if (node)
    *node = ckt->sys_mat->n_melem;

  if (elem)
    *elem = ckt->n_elem;

  if (precond)
    *precond = ckt->pre_mat->n_melem;
}

double ckt_diag(ckt_t *ckt)
{
  return mat_diag(ckt->sys_mat);    
}

void ckt_comp_extreme_no_error(ckt_t *ckt, component_t *comp, double *min_voltage, double *max_voltage, double * node_v )
{
  int index;
  double v_pos_node, v_neg_node;

  assert(comp->n_pos_port == comp->n_neg_port);
  *min_voltage = 1000;
  *max_voltage = -1000;
  
  for(index = 0; index < comp->n_pos_port; index++) {
    v_pos_node = ckt->v_vec[abs(comp->ports[(index << 1)])];
    v_neg_node = ckt->v_vec[abs(comp->ports[(index << 1)+1])];
	node_v[index] = (v_pos_node-v_neg_node);
	
    *min_voltage = MIN(*min_voltage, node_v[index]);
    *max_voltage = MAX(*max_voltage, node_v[index]);
  }
}

void ckt_comp_extreme(ckt_t *ckt, component_t *comp, double *min_voltage, double *max_voltage, double * node_v )
{
	ckt_comp_extreme_with_ir_drop(ckt, comp, min_voltage, max_voltage, node_v, NULL);
}

void ckt_comp_extreme_with_ir_drop(ckt_t *ckt, component_t *comp, double *min_voltage, double *max_voltage, double * node_v, component_t *comp2)
{
  int index;
  double v_pos_node, v_neg_node;

  assert(comp->n_pos_port == comp->n_neg_port);
  *min_voltage = 1000;
  *max_voltage = -1000;
  
  if ( comp2 ) {
   	assert(comp->n_pos_port == comp2->n_pos_port);
  }

  for(index = 0; index < comp->n_pos_port; index++) {
    v_pos_node = ckt->v_vec[abs(comp->ports[(index << 1)])];
    v_neg_node = ckt->v_vec[abs(comp->ports[(index << 1)+1])];
    //printf("%d %lf(%lf %lf)\n",abs(comp->ports[(index << 1)]),v_pos_node-v_neg_node,v_pos_node,v_neg_node);

    //if ((v_pos_node - v_neg_node) < 0.5)
    if ((v_pos_node - v_neg_node) < 0.1) {
      fprintf(stderr, "Problem here...(%d,%d) %s:%lf\n", abs(comp->ports[(index
      << 1)]), abs(comp->ports[(index << 1)+1]),comp->name,v_pos_node - v_neg_node);
    }

	node_v[index] = (v_pos_node-v_neg_node);
	
	if ( comp2 ) {
		double v_pos_node2 = ckt->v_vec[abs(comp2->ports[(index << 1)])];
		double v_neg_node2 = ckt->v_vec[abs(comp2->ports[(index << 1)+1])];
    	//printf("%f %f\n", v_pos_node2, v_neg_node2);
		node_v[index] += (v_pos_node2 - v_neg_node2)*2;
	}
    *min_voltage = MIN(*min_voltage, node_v[index]);
    *max_voltage = MAX(*max_voltage, node_v[index]);
  }
}

double ckt_comp_mean(ckt_t *ckt, component_t *comp)
{
  int index;
  double v_pos_node, v_neg_node, v_sum = 0.0;

  assert(comp->n_pos_port == comp->n_neg_port);

  for(index = 0; index < comp->n_pos_port; index++) {
    v_pos_node = ckt->v_vec[abs(comp->ports[(index << 1)])];
    v_neg_node = ckt->v_vec[abs(comp->ports[(index << 1)+1])];

//    printf("ckt_comp_mean(): %lf \n",v_pos_node - v_neg_node);
    v_sum += v_pos_node - v_neg_node;
  }

  return v_sum / comp->n_pos_port;
}
