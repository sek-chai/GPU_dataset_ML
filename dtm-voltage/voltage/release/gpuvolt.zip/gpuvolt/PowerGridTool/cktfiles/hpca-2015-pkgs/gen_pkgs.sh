#!/bin/bash

pkg_id=$1

if [ $pkg_id -eq 1 ]; then
	LUMPED_R_SCALING=2
	LUMPED_L_SCALING=2
	LUMPED_C_SCALING=4
	PACKAGE_SERIAL_SCALING=2
	PACKAGE_PARALLEL_SCALING=2
elif [ $pkg_id -eq 2 ]; then
	LUMPED_R_SCALING=1.5
	LUMPED_L_SCALING=1.5
	LUMPED_C_SCALING=3
	PACKAGE_SERIAL_SCALING=1.5
	PACKAGE_PARALLEL_SCALING=1.5
elif [ $pkg_id -eq 3 ]; then # both 1st and 2nd droop larger
	LUMPED_R_SCALING=1
	LUMPED_L_SCALING=1
	LUMPED_C_SCALING=2
	PACKAGE_SERIAL_SCALING=1
	PACKAGE_PARALLEL_SCALING=1
elif [ $pkg_id -eq 4 ]; then # large 2nd droop
	LUMPED_R_SCALING=2
	LUMPED_L_SCALING=2
	LUMPED_C_SCALING=4
	PACKAGE_SERIAL_SCALING=1
	PACKAGE_PARALLEL_SCALING=1
elif [ $pkg_id -eq 5 ]; then # large 1st droop
	LUMPED_R_SCALING=1
	LUMPED_L_SCALING=1
	LUMPED_C_SCALING=2
	PACKAGE_SERIAL_SCALING=2
	PACKAGE_PARALLEL_SCALING=2
else
	echo "pkg id not supported yet!"
	exit
fi



cp ckt_gen.cpp.template  ckt_gen.cpp
for str in LUMPED_R_SCALING LUMPED_L_SCALING  LUMPED_C_SCALING PACKAGE_SERIAL_SCALING PACKAGE_PARALLEL_SCALING; do
	eval str_val=\$$str
	echo "s/^#define $str.*/#define $str $str_val/" 
	sed -i  "s/^#define $str.*/#define $str $str_val/" ckt_gen.cpp

done

g++ ckt_gen.cpp -o ckt_gen
./ckt_gen 3 2 0.5
./transform.sh 3 2

mkdir -p pkg-$pkg_id
mv fermi.ckt pkg-$pkg_id
mv fermi.grid.r pkg-$pkg_id
mv fermi.map pkg-$pkg_id
