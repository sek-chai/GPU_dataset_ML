#!/bin/bash

num_points_h=$1
num_points_v=$2
rm -f fermi.map.tmp
for i in `seq 0 24`;
do
	cat fermi.map | grep "^core$i "	>> fermi.map.tmp
	cat fermi.map | grep "^l2cache$i "   >> fermi.map.tmp
done

if [ "1" ]; then
	for i in `seq 0 24`;
	do
		cat fermi.map | grep "^r_core$i "	>> fermi.map.tmp
		cat fermi.map | grep "^r_l2cache$i "   >> fermi.map.tmp
	done
	cat fermi.map | grep "r_pkg"    >> fermi.map.tmp
fi

mv fermi.map.tmp fermi.map

awk "BEGI{count=0;} { if(count % ( $num_points_h * $num_points_v ) == 0){ if(count != 0) printf(\"\n\"); printf(\"%s %s %s \", $ 1, $ 2, $ 3) } else { printf(\"%s %s \", $ 2, $ 3); } count++; }" fermi.map > fermi.map.tmp
mv fermi.map.tmp fermi.map
