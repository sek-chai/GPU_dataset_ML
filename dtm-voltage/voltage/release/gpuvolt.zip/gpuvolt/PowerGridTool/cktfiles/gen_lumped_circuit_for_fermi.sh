#!/bin/bash

sed -i "s/^int h_cmps=.*;/int h_cmps=1;/" ckt_gen.cpp
sed -i "s/^int v_cmps=.*;/int v_cmps=1;/" ckt_gen.cpp
make

./ckt_gen 1 1 0.5
./transform.sh 1 1
