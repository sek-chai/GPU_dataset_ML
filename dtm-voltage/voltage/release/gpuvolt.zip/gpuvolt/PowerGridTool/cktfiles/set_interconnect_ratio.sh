function set_interconnect_ratio {
	`sed "s/^\#define INTERCONNECT_RATIO .*$/#define INTERCONNECT_RATIO $target/" $TEMPLATE > $OUTPUT`
}

target=$1
TEMPLATE=ckt_gen.cpp.template.cpp
OUTPUT=ckt_gen_from_template.cpp
set_interconnect_ratio
BIN_NAME=`echo $OUTPUT | awk -F'.' '{print $1}'`

#echo "g++ $OUTPUT -o $BIN_NAME"
g++ $OUTPUT -o $BIN_NAME


./$BIN_NAME 3 2 0.5
./transform.sh 3 2
