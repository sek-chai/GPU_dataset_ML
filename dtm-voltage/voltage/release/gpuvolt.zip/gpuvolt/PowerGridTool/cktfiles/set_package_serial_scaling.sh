function set_interconnect_ratio {
	echo set_interconnect_ratio

}

function set_package_serial_scaling {
	#sed 's/^\#define PACKAGE_SERIAL_SCALING .*$/#define PACKAGE_SERIAL_SCALING $1/" $TEMPLATE > $TEMPLATE.tmp
	`sed "s/^\#define PACKAGE_SERIAL_SCALING .*$/#define PACKAGE_SERIAL_SCALING $target/" $TEMPLATE > $OUTPUT`
	`sed -i "s/^\#define PACKAGE_PARALLEL_SCALING .*$/#define PACKAGE_PARALLEL_SCALING $target/" $OUTPUT`
	#echo "sed 's/^\#define PACKAGE_SERIAL_SCALING .*$/#define PACKAGE_SERIAL_SCALING 0.1/' $TEMPLATE > $TEMPLATE.tmp"
}

target=$1
TEMPLATE=ckt_gen.cpp.template.cpp
OUTPUT=ckt_gen_from_template.cpp
set_package_serial_scaling $1
BIN_NAME=`echo $OUTPUT | awk -F'.' '{print $1}'`

#echo "g++ $OUTPUT -o $BIN_NAME"
g++ $OUTPUT -o $BIN_NAME


./$BIN_NAME 3 2 0.5
./transform.sh 3 2
