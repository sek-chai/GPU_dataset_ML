#include <stdio.h>
#include <assert.h>
#include "ckt_gen.h"
#include <stdlib.h>

#define LUMPED_R 0.0005f // mohm
#define LUMPED_L 0.00381972186058652f
#define LUMPED_C 1697.65416026067f
//#define LUMPED_L 0.00636620310097753f
//#define LUMPED_C 1018.5924961564f
#define CLOCK_FREQ 7.0e8f

#define BUMP_VDD_R 0.004
#define BUMP_VDD_L 7.2e-12

#define LUMPED_DISTRIBUTED_RATIO  0.01f

#define BUMP_GND_R 0.004
#define BUMP_GND_L 7.2e-12

//#define CORE_GRID_RATIO 1.2f
#define CORE_GRID_RATIO 1.2f

#define FAKE_NODE 200

double grid_R, grid_L, grid_C;
double core_grid_ratio, non_core_grid_ratio;
double lumped_R = LUMPED_R;
double lumped_L = LUMPED_L/CLOCK_FREQ;
double lumped_C = LUMPED_C/CLOCK_FREQ;

unsigned long Node::next_id = 0;
unsigned long Edge::next_id = 0;
int h_cmps=4;
int v_cmps=6;

int h_nodes=h_cmps;
int v_nodes=v_cmps;

Node::Node() {
	u_id = next_id;
	next_id ++;
}

Node::~Node() {
}

CircuitNode::CircuitNode() {
}

CircuitNode::~CircuitNode() {
}

Edge::Edge() {
	u_id = next_id;
	next_id ++;
}

unsigned CircuitNode::get_global_id() {
	return (3000+u_id);

}

unsigned CircuitEdge::get_internal_id( ) {
	return (4000+u_id);
}

unsigned CircuitNode::get_internal_id( ) {
	return (5000+u_id);
}

unsigned CircuitNode::get_bump_internal_id( ) {
	return (7000+u_id);
}

unsigned CircuitNode::get_bump2_internal_id( ) {
	return (9000+u_id);
}

unsigned CircuitNode::get_input_node_id( ) { // for vdd
	return (1000+u_id);
}

unsigned CircuitNode::get_input2_node_id( ) { // for gnd
	return (2000+u_id);
}

void CircuitNode::set_name( char * n) {
	sprintf(name, "%s", n);
	sprintf(resistance_node_name, "resistance_%s", n);
}

CircuitEdge::CircuitEdge(CircuitNode* n1, CircuitNode* n2) {
	if (n1->u_id <= n2->u_id) {
		node1=n1;
		node2=n2;
	}else {
		node1=n2;
		node2=n1;
	}
}

void Circuit::print_edges(FILE * out) {
	Circuit::EdgeIter edge_iter;
	Circuit::EdgeIter edge_begin = edges.begin();
	Circuit::EdgeIter edge_end   = edges.end();

	for ( edge_iter = edge_begin; edge_iter != edge_end; edge_iter ++ ) {
		unsigned node1_name;
		unsigned node2_name;
		unsigned internal_node_name;
		//node1_name = (*edge_iter)->get_node1()->get_global_id();
		//node2_name = (*edge_iter)->get_node2()->get_global_id();
		node1_name = (*edge_iter)->get_node1()->get_input_node_id();
		node2_name = (*edge_iter)->get_node2()->get_input_node_id();
		internal_node_name = (*edge_iter)->get_internal_id();
		fprintf(out, "R%d_%d %d %d ", node1_name, internal_node_name, node1_name, internal_node_name);
		(*edge_iter)->print_R(out);
		fprintf(out, "\n");
		fprintf(out, "L%d_%d %d %d ", node2_name, internal_node_name, node2_name, internal_node_name); 
		(*edge_iter)->print_L(out);
		fprintf(out, "\n");
	
	}
}

void Circuit::print_nodes(FILE * out) {
	Circuit::NodeIter node_iter;
	Circuit::NodeIter node_begin = nodes.begin();
	Circuit::NodeIter node_end   = nodes.end();

	// inside grid
	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned node_name;
		unsigned internal_node_name;
		unsigned ground_name;
		unsigned input_name, input2_name;
		node_name 			= (*node_iter)->get_global_id();
		internal_node_name 	= (*node_iter)->get_internal_id();
		ground_name			= get_ground();
		input_name 			= (*node_iter)->get_input_node_id();
		input2_name 			= (*node_iter)->get_input2_node_id();
		fprintf(out, "R%d_%d %d %d ", internal_node_name, input_name, internal_node_name, input_name); 		 
		(*node_iter)->print_R(out);
		fprintf(out, "\n");
		fprintf(out, "L%d_%d %d %d ", node_name, internal_node_name, node_name, internal_node_name); 
		(*node_iter)->print_L(out);
		fprintf(out, "\n");
		fprintf(out, "C%d_%d %d %d ", input_name,input2_name,input_name,input2_name);
		(*node_iter)->print_C(out);
		fprintf(out, "\n");
	}

	// connect vdd
	fprintf(out, "\n");
	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned node_name;
		unsigned internal_node_name;
		unsigned internal_node_name2;
		unsigned ground_name;
		unsigned input_name, input2_name;
		node_name 			= (*node_iter)->get_global_id();
		internal_node_name 	= (*node_iter)->get_bump_internal_id();
		input_name 			= (*node_iter)->get_input_node_id();
		input2_name 			= (*node_iter)->get_input2_node_id();
		internal_node_name2 	= (*node_iter)->get_bump2_internal_id();
		fprintf(out, "R%d_%d %d %d %e\n", node_name, internal_node_name, node_name, internal_node_name, grid_R/50); 		 
		fprintf(out, "L%d_%d %d %d %e\n", internal_node_name, 6000, internal_node_name,6000, grid_L/50); 
		fprintf(out, "R%d_%d %d %d %e\n", input2_name, internal_node_name2, input2_name, internal_node_name2, grid_R/50); 		 
		fprintf(out, "L%d_%d %d %d %e\n", internal_node_name2, 8000, internal_node_name2, 8000, grid_L/50); 
	}
}

void Circuit::print_vdd(FILE * out) {
	//fprintf(out, "*VDD 100 0 1.12\n");
	fprintf(out, "VDD 100 0 1.00\n");
	fprintf(out, "VGND 200 0 0.0\n");
	fprintf(out, "\n");

	fprintf(out, "R100_101 100 101 %e\n", lumped_R/100 );
	fprintf(out, "L101_102 101 102 %e\n", lumped_L/100);  // pcb board to package vdd
	fprintf(out, "R200_201 200 201 %e\n", lumped_R/100);
	fprintf(out, "L201_202 201 202 %e\n", lumped_L/100);  // pcb board to package gnd
	fprintf(out, "\n");

	fprintf(out, "C102_10000 102 10000 0.0024\n"); 
	fprintf(out, "R10000_202 10000 202 0.166e-03\n"); // pcb r,c connecting the vdd and gnd into the package
	fprintf(out, "\n");

	fprintf(out, "R102_103 102 103 %e\n",   lumped_R*LUMPED_DISTRIBUTED_RATIO);
	fprintf(out, "L103_6000 103 6000 %e\n", lumped_L*LUMPED_DISTRIBUTED_RATIO);  	// package serial vdd
	fprintf(out, "R202_203 202 203 %e\n",   lumped_R/100);
	fprintf(out, "L203_8000 203 8000 %e\n", lumped_L/100);		// package serial gnd
	fprintf(out, "\n");

	fprintf(out, "C6000_10001 6000 10001 2.6e-04\n");  
	fprintf(out, "R10001_8000 10001 10002 0.005415\n");
	fprintf(out, "L10002_8000 10002 8000 5.61e-11\n");  // package parallel 
	fprintf(out, "\n");
}

void Circuit::print_netlist(FILE * out) {
	print_edges(out);	
	fprintf(out, "\n\n\n");
	print_nodes(out);
	fprintf(out, "\n\n\n");
	print_vdd(out);
}

void Circuit::print_mapfile(FILE * out) {
	Circuit::NodeIter node_iter;
	Circuit::NodeIter node_begin = nodes.begin();
	Circuit::NodeIter node_end   = nodes.end();

	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned node_name;
		unsigned internal_node_name;
		unsigned ground_name;
		unsigned input_name;
		unsigned input_name2;
		node_name 			= (*node_iter)->get_global_id();
		internal_node_name 	= (*node_iter)->get_internal_id();
		ground_name			= get_ground();
		input_name 			= (*node_iter)->get_input_node_id();
		input_name2 		= (*node_iter)->get_input2_node_id();
		fprintf(out, "%s %d -%d\n", (*node_iter)->get_comp_name(), input_name, input_name2); 		 
	}

	// fake nodes to calculate IR drop
	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned node_name;
		unsigned internal_node_name;
		unsigned ground_name;
		unsigned input_name;
		unsigned input_name2;
		node_name 			= (*node_iter)->get_global_id();
		internal_node_name 	= (*node_iter)->get_internal_id();
		ground_name			= get_ground();
		input_name 			= (*node_iter)->get_input_node_id();
		input_name2 		= (*node_iter)->get_input2_node_id();
		//fprintf(out, "%s %d -%d\n", (*node_iter)->get_fake_comp_name(), internal_node_name, input_name2); 		 
		//fprintf(out, "%s %d -%d\n", (*node_iter)->get_fake_comp_name(), internal_node_name, ground_name); 		 
	}
}


unsigned num_of_points_per_core = 1;
int main(int argc, char *argv[]) {

	assert(argc >= 2);

	int ratio_invert = atoi(argv[1]);

	if (argc == 3) {
		num_of_points_per_core = atoi(argv[2]);
	}
	fprintf(stdout, "number of points per core = %d\n", num_of_points_per_core*num_of_points_per_core); 

	double INTERCONNECT_RATIO;
	if ( ratio_invert != 0 )
		INTERCONNECT_RATIO = (double)(ratio_invert);
	else
		INTERCONNECT_RATIO = 0;

	Circuit circuit;
	circuit.set_ground(8000);

	v_nodes*=num_of_points_per_core;
	h_nodes*=num_of_points_per_core;

	int node_count = h_nodes * v_nodes;
	circuit.clear();
	circuit.resize_nodes(node_count);
	int node_index = 0;

	//========================
	//    construct nodes
	//========================
	grid_R = lumped_R * node_count; //* (1-LUMPED_DISTRIBUTED_RATIO);
	grid_L = lumped_L * node_count; //* (1-LUMPED_DISTRIBUTED_RATIO);
	grid_C = lumped_C / node_count;
	core_grid_ratio = CORE_GRID_RATIO;

	FILE *r_file = fopen("fermi.grid.r", "w");
	non_core_grid_ratio = 3.0f - 2.0f * core_grid_ratio;
	assert(non_core_grid_ratio > 0 && "non core grid ratio smaller than 0!");
	assert(non_core_grid_ratio <= 1.0 && "non core grid ratio bigger than 1!");

	assert( r_file != NULL);
	fprintf(r_file, "%f\n", grid_R/core_grid_ratio); 
	fprintf(r_file, "%f\n", grid_R/non_core_grid_ratio); 
	fclose(r_file);
	r_file = NULL;

	fprintf(stdout, "grid_R %e\n", grid_R);
	fprintf(stdout, "grid_L %e\n", grid_L);
	fprintf(stdout, "grid_C %e\n", grid_C);

	int core_count=0;
	for (int i = 0; i<v_nodes; i ++ ) {
		for (int j = 0; j<h_nodes; j ++ ) {
			CircuitNode * node = new CircuitNode;

			char comp_name[100];
			core_count = (int)(i/num_of_points_per_core)*h_cmps+ j/num_of_points_per_core ;

			if( core_count < 8 || core_count > 15) {
				sprintf(comp_name, "core%d", core_count);
				node->set_name(comp_name);
				node->set_RLC(grid_R/core_grid_ratio, grid_L/core_grid_ratio, grid_C*core_grid_ratio);
			} else {
				sprintf(comp_name, "l2cache%d", core_count);
				node->set_RLC(grid_R/non_core_grid_ratio, grid_L/non_core_grid_ratio, grid_C*non_core_grid_ratio);
				node->set_name(comp_name);
			}

			//fprintf(stderr, "node <%d, %d> id=%d\n", i, j, nodes[node_index]->getId());
			circuit.add_node(node, node_index);
			node_index += 1;
		}
	}


	//========================
	// 		   edges
	//========================
	// horizontal
	double inter_R, inter_L, inter_C;
	inter_R = lumped_R * INTERCONNECT_RATIO/(num_of_points_per_core*num_of_points_per_core);  
	inter_L = lumped_L * INTERCONNECT_RATIO/(num_of_points_per_core*num_of_points_per_core);
	fprintf(stdout, "Horizontal inter_R %e\n", inter_R);
	fprintf(stdout, "Horizontal inter_L %e\n", inter_L);
	for (int i = 0; i<v_nodes; i ++ ) {
		for (int j = 0; j<h_nodes; j ++ ) {
			if ( j > 0 ) {
				node_index=i*(h_nodes)+j;
				//fprintf(stderr, "noe_index %d tmp %d\n", node_index, tmp);
				CircuitEdge * edge=new CircuitEdge(circuit.get_node(node_index), circuit.get_node(node_index-1));
				edge->set_RL(inter_R, inter_L);
				//fprintf(stderr, "edge %d node %d to node %d\n", edge->getId(), edge->node1->getId(), edge->node2->getId());
				circuit.add_edge(edge);
			}
		}
	}

	// vertical
	inter_R = lumped_R * INTERCONNECT_RATIO/(num_of_points_per_core*num_of_points_per_core) * h_nodes / v_nodes;  
	inter_L = lumped_L * INTERCONNECT_RATIO/(num_of_points_per_core*num_of_points_per_core) * h_nodes / v_nodes;  
	fprintf(stdout, "Vertical inter_R %e\n", inter_R);
	fprintf(stdout, "Vertical inter_L %e\n", inter_L);
	for (int i = 0; i<v_nodes; i ++ ) {
		for (int j = 0; j<h_nodes; j ++ ) {
			if ( i > 0 ) {
				int node_index1 = i*h_nodes + j;
				int node_index2 = (i-1)*h_nodes + j;
				CircuitEdge * edge=new CircuitEdge(circuit.get_node(node_index1), circuit.get_node(node_index2));
				edge->set_RL(inter_R, inter_L);
				circuit.add_edge(edge);
			}
		}
	}

	//========================
	// 		   iterate 
	//========================
	Circuit::EdgeIter edge_iter;
	Circuit::EdgeIter edge_begin = circuit.edge_begin();
	Circuit::EdgeIter edge_end   = circuit.edge_end();
		//fprintf(stderr, "edge %d node %d to node %d", edges[i]->getId(), edges[i]->node1->getId(), edges->node2->getId());
//	for ( edge_iter = edge_begin; edge_iter != edge_end; edge_iter++ )
//		fprintf(stderr, "edge %d\n", (*edge_iter)->getId());
	char out_str[1024];
	sprintf(out_str, "fermi.%d.ckt", ratio_invert);
	FILE * out = fopen(out_str, "w");
	assert(out != NULL);
	circuit.print_netlist(out);
	fclose(out);
	out = fopen("fermi.map", "w");
	assert(out != NULL);
	circuit.print_mapfile(out);
	fclose(out);
	return 1;
}
