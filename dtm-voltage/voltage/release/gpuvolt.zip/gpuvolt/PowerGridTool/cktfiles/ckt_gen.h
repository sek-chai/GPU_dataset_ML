#include <vector>

class Edge;
class Node {
	private:

	public:
	unsigned long u_id;
	static unsigned long next_id;
	typedef std::vector<Node *>::iterator iterator;
	std::vector<Edge*> edges;

	Node();
	~Node();

	unsigned long getId() {return u_id;}
};

class Edge {
	public:
	unsigned long u_id;
	static unsigned long next_id;

	Edge(Node*, Node*);
	Edge();
	
	unsigned long getId() {return u_id;}
};

class CircuitNode: public Node {
	public:
	double R,L,C;
	char name[100];
	char resistance_node_name[100];


	CircuitNode();
	~CircuitNode();

	void print_R(FILE *out) { fprintf(out, "%e", R); }
	void print_L(FILE *out) { fprintf(out, "%e", L); }
	void print_C(FILE *out) { fprintf(out, "%e", C); }

	unsigned get_vdd_bump_internal_id();
	unsigned get_gnd_bump_internal_id();
	unsigned get_bump_internal_id();
	unsigned get_vdd_node_id();
	unsigned get_gnd_node_id();
	unsigned get_bump2_internal_id(); // gnd
	void set_RLC(double r, double l, double c) { R=r; L=l; C=c;}
	void set_name(char *);
	char* get_comp_name() { return name;}
	char* get_fake_comp_name() { return resistance_node_name;}
};


class CircuitEdge: public Edge{
	public:
	double L, R;
	CircuitNode * node1;
	CircuitNode * node2;
	CircuitEdge(CircuitNode* n1, CircuitNode* n2);
	CircuitNode * get_node1() { return node1; }
	CircuitNode * get_node2() { return node2; }

	double get_R() { return R; }
	double get_L() { return L; }
	void set_RL(double r, double l) { R=r; L=l; }

	void print_R(FILE *out) { fprintf(out, "%e", R); }
	void print_L(FILE *out) { fprintf(out, "%e", L); }

	unsigned get_vdd_plane_id();
	unsigned get_gnd_plane_id();
};

class Circuit {
	public:
	unsigned ground;
	
	std::vector<CircuitNode *> nodes;
	std::vector<CircuitEdge *> edges;

	void resize_nodes(unsigned size) { nodes.resize(size);}
	void add_node(CircuitNode * node) { nodes.push_back(node);}
	void add_edge(CircuitEdge* edge) { edges.push_back(edge);}
	void add_node(CircuitNode * node, unsigned i) { nodes[i]=node;}

	CircuitNode * get_node(unsigned i) { return nodes[i];}
	CircuitEdge * get_edge(unsigned i) { return edges[i];}

	void clear() { nodes.clear(); edges.clear();}

	typedef std::vector<CircuitNode *>::iterator NodeIter;
	typedef std::vector<CircuitEdge *>::iterator EdgeIter;
	NodeIter node_begin() { return nodes.begin();}
	NodeIter node_end() { return nodes.end();}
	EdgeIter edge_begin() { return edges.begin();}
	EdgeIter edge_end() { return edges.end();}

	void print_netlist(FILE *);
	void print_mapfile(FILE *);
	void print_edges(FILE *);
	void print_nodes(FILE *);
	void print_vdd(FILE *);

	void set_ground(unsigned val) { ground = val; }
	unsigned get_ground() { return ground; }

};
