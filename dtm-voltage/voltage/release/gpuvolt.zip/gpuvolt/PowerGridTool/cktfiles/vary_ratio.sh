for i in `seq 8 8 256`;do
	./ckt_gen_with_arg $i
done
