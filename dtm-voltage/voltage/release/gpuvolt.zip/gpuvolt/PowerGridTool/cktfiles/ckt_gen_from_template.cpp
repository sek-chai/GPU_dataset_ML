#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "ckt_gen.h"

//#define LUMPED_R 0.0005f // mohm
//#define LUMPED_L 0.00381972186058652f
//#define LUMPED_C 1697.65416026067f
//#define LUMPED_R 0.0006// mohm
//#define LUMPED_L 10e-13f 

#define LUMPED_R 0.000278f// mohm
#define LUMPED_L 5e-13f
#define LUMPED_C 335e-9f 

#define LUMPED_R_SCALING 2
#define LUMPED_L_SCALING 2
#define LUMPED_C_SCALING 4
#define PACKAGE_SERIAL_SCALING 4.0f
#define PACKAGE_PARALLEL_SCALING 4.0f

//#define PACKAGE_SERIAL_SCALING 1
//#define PACKAGE_PARALLEL_SCALING 1

//#define LUMPED_R_SCALING 1 
//#define LUMPED_L_SCALING 1 
//#define LUMPED_C_SCALING 1 
//#define PACKAGE_SERIAL_SCALING   1 
//#define PACKAGE_PARALLEL_SCALING 1 

//#define LUMPED_L 0.00636620310097753f
//#define LUMPED_C 1018.5924961564f
//#define INTERCONNECT_RATIO ((double)(3))
#define INTERCONNECT_RATIO 3.0f
//#define CLOCK_FREQ 7.0e8f
#define CLOCK_FREQ 1.0f

#define BUMP_VDD_R 0.004
#define BUMP_VDD_L 7.2e-12

#define BUMP_GND_R 0.004
#define BUMP_GND_L 7.2e-12

#define CORE_GRID_RATIO 1.0f

#define FAKE_NODE 200

double grid_R, grid_L, grid_C;
double core_grid_ratio, non_core_grid_ratio;
double lumped_R = LUMPED_R / LUMPED_R_SCALING;
double lumped_L = LUMPED_L / CLOCK_FREQ / LUMPED_L_SCALING;
double lumped_C = LUMPED_C / CLOCK_FREQ * LUMPED_C_SCALING;

unsigned long Node::next_id = 0;
unsigned long Edge::next_id = 0;
//int h_cmps=1;
//int v_cmps=1;
int h_cmps=4;
int v_cmps=6;

int h_nodes;
int v_nodes;

Node::Node() {
	u_id = next_id;
	next_id ++;
}

Node::~Node() {
}

CircuitNode::CircuitNode() {
}

CircuitNode::~CircuitNode() {
}

Edge::Edge() {
	u_id = next_id;
	next_id ++;
}

unsigned CircuitEdge::get_vdd_plane_id( ) {
	return (60000+u_id);
}

unsigned CircuitEdge::get_gnd_plane_id( ) {
	return (80000+u_id);
}

unsigned CircuitNode::get_vdd_bump_internal_id( ) {
	return (50000+u_id);
}

unsigned CircuitNode::get_gnd_bump_internal_id( ) {
	return (40000+u_id);
}

unsigned CircuitNode::get_bump_internal_id( ) {
	return (70000+u_id);
}

unsigned CircuitNode::get_bump2_internal_id( ) {
	return (90000+u_id);
}

unsigned CircuitNode::get_vdd_node_id( ) { // for vdd
	return (10000+u_id);
}

unsigned CircuitNode::get_gnd_node_id( ) { // for gnd
	return (20000+u_id);
}

void CircuitNode::set_name( char * n) {
	sprintf(name, "%s", n);
	sprintf(resistance_node_name, "r_%s", n);
	//sprintf(resistance_node_name, "r_%d", u_id);
}

CircuitEdge::CircuitEdge(CircuitNode* n1, CircuitNode* n2) {
	if (n1->u_id <= n2->u_id) {
		node1=n1;
		node2=n2;
	}else {
		node1=n2;
		node2=n1;
	}
}

void Circuit::print_edges(FILE * out) {
	Circuit::EdgeIter edge_iter;
	Circuit::EdgeIter edge_begin = edges.begin();
	Circuit::EdgeIter edge_end   = edges.end();

	// VDD plane
	for ( edge_iter = edge_begin; edge_iter != edge_end; edge_iter ++ ) {
		unsigned node1_name;
		unsigned node2_name;
		unsigned internal_node_name;
		node1_name = (*edge_iter)->get_node1()->get_vdd_node_id();
		node2_name = (*edge_iter)->get_node2()->get_vdd_node_id();
		internal_node_name = (*edge_iter)->get_vdd_plane_id();
		fprintf(out, "R%d_%d %d %d ", node1_name, internal_node_name, node1_name, internal_node_name);
		(*edge_iter)->print_R(out);
		fprintf(out, "\n");
		fprintf(out, "L%d_%d %d %d ", node2_name, internal_node_name, node2_name, internal_node_name); 
		(*edge_iter)->print_L(out);
		fprintf(out, "\n");
	}

	fprintf(out, "*gnd plane\n");
	//GND Plane
	for ( edge_iter = edge_begin; edge_iter != edge_end; edge_iter ++ ) {
		unsigned node1_name;
		unsigned node2_name;
		unsigned internal_node_name;
		node1_name = (*edge_iter)->get_node1()->get_gnd_node_id();
		node2_name = (*edge_iter)->get_node2()->get_gnd_node_id();
		internal_node_name = (*edge_iter)->get_gnd_plane_id();
		fprintf(out, "R%d_%d %d %d ", node1_name, internal_node_name, node1_name, internal_node_name);
		(*edge_iter)->print_R(out);
		fprintf(out, "\n");
		fprintf(out, "L%d_%d %d %d ", node2_name, internal_node_name, node2_name, internal_node_name); 
		(*edge_iter)->print_L(out);
		fprintf(out, "\n");
	}
}

void Circuit::print_nodes(FILE * out) {
	Circuit::NodeIter node_iter;
	Circuit::NodeIter node_begin = nodes.begin();
	Circuit::NodeIter node_end   = nodes.end();

	// connect to the vdd/gnd plane
	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned internal_node_name;
		unsigned ground_name;
		unsigned input_name, input2_name;
		internal_node_name 	= (*node_iter)->get_vdd_bump_internal_id();
		ground_name			= get_ground();
		input_name 			= (*node_iter)->get_vdd_node_id();
		input2_name 			= (*node_iter)->get_gnd_node_id();
		fprintf(out, "R%d_%d %d %d ", internal_node_name, input_name, internal_node_name, input_name); 		 
		(*node_iter)->print_R(out);
		fprintf(out, "\n");
		fprintf(out, "L%d_%d %d %d ", 6000, internal_node_name, 6000, internal_node_name); 
		(*node_iter)->print_L(out);
		fprintf(out, "\n");

		internal_node_name 	= (*node_iter)->get_gnd_bump_internal_id();
		fprintf(out, "R%d_%d %d %d ", internal_node_name, input2_name, internal_node_name, input2_name); 		 
		(*node_iter)->print_R(out);
		fprintf(out, "\n");
		fprintf(out, "L%d_%d %d %d ", 8000, internal_node_name, 8000, internal_node_name); 
		(*node_iter)->print_L(out);
		fprintf(out, "\n");

	}

	fprintf(out, "\n");
	// print caps
	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned internal_node_name;
		unsigned ground_name;
		unsigned input_name, input2_name;
		internal_node_name 	= (*node_iter)->get_vdd_bump_internal_id();
		ground_name			= get_ground();
		input_name 			= (*node_iter)->get_vdd_node_id();
		input2_name 			= (*node_iter)->get_gnd_node_id();

		fprintf(out, "C%d_%d %d %d ", input_name,input2_name,input_name,input2_name);
		(*node_iter)->print_C(out);
		fprintf(out, "\n");
	}

	// connect vdd
	#if 0
	fprintf(out, "\n");
	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned node_name;
		unsigned internal_node_name;
		unsigned internal_node_name2;
		unsigned ground_name;
		unsigned input_name, input2_name;
		internal_node_name 	= (*node_iter)->get_bump_internal_id();
		input_name 			= (*node_iter)->get_vdd_node_id();
		input2_name 			= (*node_iter)->get_gnd_node_id();
		internal_node_name2 	= (*node_iter)->get_bump2_internal_id();
		fprintf(out, "R%d_%d %d %d %e\n", node_name, internal_node_name, node_name, internal_node_name, grid_R/50); 		 
		fprintf(out, "L%d_%d %d %d %e\n", internal_node_name, 6000, internal_node_name,6000, grid_L/50); 
		fprintf(out, "R%d_%d %d %d %e\n", input2_name, internal_node_name2, input2_name, internal_node_name2, grid_R/50); 		 
		fprintf(out, "L%d_%d %d %d %e\n", internal_node_name2, 8000, internal_node_name2, 8000, grid_L/50); 
	}
	#endif
}

void Circuit::print_vdd(FILE * out) {
	//fprintf(out, "*VDD 100 0 1.12\n");
	fprintf(out, "VDD 100 0 1.0\n");
	fprintf(out, "VGND 200 0 0.0\n");

	//fprintf(out, "VDD_GND 100 200 0.0\n");
	//fprintf(out, "VGND 200 0 0.0\n");

	fprintf(out, "\n");

  	if ( 1 ) {
	fprintf(out, "R100_101 100 101 %e\n", 9.4e-5f);
	fprintf(out, "L101_102 101 102 %e\n", 2.1e-11f);  // pcb board to package vdd
	fprintf(out, "R200_201 200 201 %e\n", 9.4e-5f);
	fprintf(out, "L201_202 201 202 %e\n", 2.1e-11);  // pcb board to package gnd
	fprintf(out, "\n");

	fprintf(out, "C102_100000 102 100000 0.00024\n"); 
	fprintf(out, "R100000_202 100000 202 0.166e-03\n"); // pcb r,c connecting the vdd and gnd into the package
	fprintf(out, "\n");

	fprintf(out, "R102_103 102 103 %e\n",   (0.0011)/PACKAGE_SERIAL_SCALING);
	fprintf(out, "L103_6000 103 6000 %e\n", (1.2e-10)/PACKAGE_SERIAL_SCALING);  	// package serial vdd
	fprintf(out, "R202_203 202 203 %e\n",   (0.0011)/PACKAGE_SERIAL_SCALING);
	fprintf(out, "L203_8000 203 8000 %e\n", (1.2e-10)/PACKAGE_SERIAL_SCALING);		// package serial gnd
	fprintf(out, "\n");

	fprintf(out, "C6000_100001 6000 100001 %e\n", (2.6e-05)*PACKAGE_PARALLEL_SCALING);  
	fprintf(out, "R100001_8000 100001 100002 %e\n", (0.0005415)/PACKAGE_PARALLEL_SCALING);
	fprintf(out, "L100002_8000 100002 8000 %e\n", (5.61e-12)/PACKAGE_PARALLEL_SCALING);  // package parallel 
	fprintf(out, "\n");
	}
	else 
	{
	fprintf(out, "R100_101 100 101 %e\n", lumped_R/100 );
	fprintf(out, "L101_102 101 102 %e\n", lumped_L/100);  // pcb board to package vdd
	fprintf(out, "R200_201 200 201 %e\n", lumped_R/100);
	fprintf(out, "L201_202 201 202 %e\n", lumped_L/100);  // pcb board to package gnd
	fprintf(out, "\n");

	fprintf(out, "C102_10000 102 100000 0.0024\n"); 
	fprintf(out, "R100000_202 100000 202 0.166e-03\n"); // pcb r,c connecting the vdd and gnd into the package
	fprintf(out, "\n");

	fprintf(out, "R102_103 102 103 %e\n",   lumped_R/100);
	fprintf(out, "L103_6000 103 6000 %e\n", lumped_L/100);  	// package serial vdd
	fprintf(out, "R202_203 202 203 %e\n",   lumped_R/100);
	fprintf(out, "L203_8000 203 8000 %e\n", lumped_L/100);		// package serial gnd
	fprintf(out, "\n");

    fprintf(out, "C6000_100001 6000 100001 2.6e-04\n");
    fprintf(out, "R100001_8000 100001 100002 0.005415\n");
    fprintf(out, "L100002_8000 100002 8000 5.61e-11\n");  // package parallel 
	fprintf(out, "\n");
	}
}

void Circuit::print_netlist(FILE * out) {
	print_edges(out);	
	fprintf(out, "\n");
	print_nodes(out);
	fprintf(out, "\n");
	print_vdd(out);
}

void Circuit::print_mapfile(FILE * out) {
	Circuit::NodeIter node_iter;
	Circuit::NodeIter node_begin = nodes.begin();
	Circuit::NodeIter node_end   = nodes.end();

	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned ground_name;
		unsigned input_name;
		unsigned input_name2;
		ground_name			= get_ground();
		input_name 			= (*node_iter)->get_vdd_node_id();
		input_name2 		= (*node_iter)->get_gnd_node_id();
		fprintf(out, "%s %d -%d\n", (*node_iter)->get_comp_name(), input_name, input_name2); 		 
	}

	// fake nodes to calculate IR drop
	for ( node_iter = node_begin; node_iter != node_end; node_iter ++ ) {
		unsigned ground_name;
		unsigned input_name;
		unsigned input_name2;
		ground_name			= get_ground();
		input_name          = (*node_iter)->get_vdd_node_id();
		input_name2         = (*node_iter)->get_vdd_bump_internal_id();
		fprintf(out, "%s %d -%d\n", (*node_iter)->get_fake_comp_name(), input_name2, input_name);
	}

	fprintf(out, "r_pkg 102 -103\n");
}


unsigned num_of_points_per_core_h = 1;
unsigned num_of_points_per_core_v = 1;
float sweep_ratio = 1.0f;
float inter_r_scaling = 1;
float inter_l_scaling = 1;
int main(int argc, char *argv[]) {
	
	h_nodes=h_cmps;
	v_nodes=v_cmps;

	//assert(h_cmps*v_cmps*INTERCONNECT_RATIO*INTERCONNECT_RATIO==144);
	assert(argc>=3 && argc <= 5);

	num_of_points_per_core_h = atoi(argv[1]);
	num_of_points_per_core_v = atoi(argv[2]);

	fprintf(stdout, "number of points per core = %d\n", num_of_points_per_core_h*num_of_points_per_core_v); 

	if (argc == 4) {
		inter_r_scaling= atof(argv[3]);
		inter_l_scaling= inter_r_scaling;
	} else if (argc == 5) {
		inter_r_scaling= atof(argv[3]);
		inter_l_scaling= atof(argv[4]);
	}
	Circuit circuit;
	circuit.set_ground(8000);

	h_nodes*=num_of_points_per_core_h;
	v_nodes*=num_of_points_per_core_v;

	int node_count = h_nodes * v_nodes;
	circuit.clear();
	circuit.resize_nodes(node_count);
	int node_index = 0;

	//========================
	//    construct nodes
	//========================
	grid_R = lumped_R * node_count;
	grid_L = lumped_L * node_count;
	grid_C = lumped_C / node_count;
	//grid_R = lumped_R * 144;
	//grid_L = lumped_L * 144;
	//grid_C = lumped_C / 144;

	core_grid_ratio = CORE_GRID_RATIO;

	FILE *r_file = fopen("fermi.grid.r", "w");
	non_core_grid_ratio = 3.0f - 2.0f * core_grid_ratio;
	assert(non_core_grid_ratio > 0 && "non core grid ratio smaller than 0!");
	assert(non_core_grid_ratio <= 1.0 && "non core grid ratio bigger than 1!");

	assert( r_file != NULL);
	fprintf(r_file, "%f\n", grid_R/core_grid_ratio); 
	fprintf(r_file, "%f\n", grid_R/non_core_grid_ratio); 
	fclose(r_file);
	r_file = NULL;

	fprintf(stdout, "grid_R %e\n", grid_R);
	fprintf(stdout, "grid_L %e\n", grid_L);
	fprintf(stdout, "grid_C %e\n", grid_C);

	int core_count=0;
	int l2_count=0;
	for (int i = 0; i<v_nodes; i ++ ) {
		for (int j = 0; j<h_nodes; j ++ ) {
			CircuitNode * node = new CircuitNode;

			char comp_name[100];
			core_count = (int)(i/num_of_points_per_core_v)*h_cmps + j/num_of_points_per_core_h ;

			if( core_count < 8 || core_count > 15) {
				sprintf(comp_name, "core%d", core_count);
				node->set_name(comp_name);
				node->set_RLC(grid_R/core_grid_ratio, grid_L/core_grid_ratio, grid_C*core_grid_ratio);
			} else {
				sprintf(comp_name, "l2cache%d", core_count);
				node->set_RLC(grid_R/non_core_grid_ratio, grid_L/non_core_grid_ratio, grid_C*non_core_grid_ratio);
				node->set_name(comp_name);
			}

			//fprintf(stderr, "node <%d, %d> id=%d\n", i, j, nodes[node_index]->getId());
			circuit.add_node(node, node_index);
			node_index += 1;
		}
	}


	//========================
	// 		   edges
	//========================
	// horizontal
	double inter_R, inter_L, inter_C;

	//inter_R = 0.05 * INTERCONNECT_RATIO / (double)(num_of_points_per_core * num_of_points_per_core);  
	//inter_L = 5.82341325190349e-15 * INTERCONNECT_RATIO / (double)(num_of_points_per_core * num_of_points_per_core);  
	//inter_R = 0.05 / INTERCONNECT_RATIO * (double)(num_of_points_per_core * num_of_points_per_core);  
	//inter_L = 5.82341325190349e-15 / INTERCONNECT_RATIO * (double)(num_of_points_per_core * num_of_points_per_core);  
	//inter_R = 0.05 / INTERCONNECT_RATIO * (double)(num_of_points_per_core);  
	//inter_L = 5.82341325190349e-15 / INTERCONNECT_RATIO * (double)(num_of_points_per_core);  
	//inter_R = 0.05 * 1 / (double)(num_of_points_per_core);  
	//inter_L = 5.82341325190349e-15 * 1 / (double)(num_of_points_per_core);  
	
	inter_R = 0.05 * (h_cmps*INTERCONNECT_RATIO-1) / (double)(h_cmps*num_of_points_per_core_h-1) * sweep_ratio * inter_r_scaling;  
	inter_L = 5.82341325190349e-15 * (h_cmps*INTERCONNECT_RATIO-1) / (double)(h_cmps*num_of_points_per_core_h-1) * sweep_ratio * inter_l_scaling;  

	fprintf(stdout, "Horizontal inter_R %e\n", inter_R);
	fprintf(stdout, "Horizontal inter_L %e\n", inter_L);

	for (int i = 0; i<v_nodes; i ++ ) {
		for (int j = 0; j<h_nodes; j ++ ) {
			if ( j > 0 ) {
				node_index=i*(h_nodes)+j;
				//fprintf(stderr, "noe_index %d tmp %d\n", node_index, tmp);
				CircuitEdge * edge=new CircuitEdge(circuit.get_node(node_index), circuit.get_node(node_index-1));
				edge->set_RL(inter_R, inter_L);
				//fprintf(stderr, "edge %d node %d to node %d\n", edge->getId(), edge->node1->getId(), edge->node2->getId());
				circuit.add_edge(edge);
			}
		}
	}

	inter_R *= (float)(h_cmps*num_of_points_per_core_h)/(float)(v_cmps*num_of_points_per_core_v);
	inter_L *= (float)(h_cmps*num_of_points_per_core_h)/(float)(v_cmps*num_of_points_per_core_v);
	
	fprintf(stdout, "Vertical inter_R %e\n", inter_R);
	fprintf(stdout, "Vertical inter_L %e\n", inter_L);
	for (int i = 0; i<v_nodes; i ++ ) {
		for (int j = 0; j<h_nodes; j ++ ) {
			if ( i > 0 ) {
				int node_index1 = i*h_nodes + j;
				int node_index2 = (i-1)*h_nodes + j;
				CircuitEdge * edge=new CircuitEdge(circuit.get_node(node_index1), circuit.get_node(node_index2));
				edge->set_RL(inter_R, inter_L);
				circuit.add_edge(edge);
			}
		}
	}

	//========================
	// 		   iterate 
	//========================
	Circuit::EdgeIter edge_iter;
	Circuit::EdgeIter edge_begin = circuit.edge_begin();
	Circuit::EdgeIter edge_end   = circuit.edge_end();
		//fprintf(stderr, "edge %d node %d to node %d", edges[i]->getId(), edges[i]->node1->getId(), edges->node2->getId());
//	for ( edge_iter = edge_begin; edge_iter != edge_end; edge_iter++ )
//		fprintf(stderr, "edge %d\n", (*edge_iter)->getId());
	FILE * out = fopen("fermi.ckt", "w");
	assert(out != NULL);
	circuit.print_netlist(out);
	fclose(out);
	out = fopen("fermi.map", "w");
	assert(out != NULL);
	circuit.print_mapfile(out);
	fclose(out);
	return 1;
}
