#!/bin/bash

sed -i "s/^int h_cmps=.*;/int h_cmps=4;/" ckt_gen.cpp
sed -i "s/^int v_cmps=.*;/int v_cmps=6;/" ckt_gen.cpp
make

./ckt_gen 3 2 0.5
./transform.sh 3 2
