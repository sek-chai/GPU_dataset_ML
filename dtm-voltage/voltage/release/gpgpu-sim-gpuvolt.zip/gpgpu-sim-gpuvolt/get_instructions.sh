infile=$1
logdir=$2
numkerns=$3
numcores=$4

kern_start=1
for (( kern=0; kern < $numkerns; kern++ ))
do
	echo $kern
	kern_end=`grep -n "Kernel $kern OP Classification" $infile | tail -n 1  | cut -f 1 -d ':'`
	sed -n "$kern_start,$kern_end"p $infile > kern_infile_$kern
	kern_start=$kern_end

	maxcycles=`grep "gpu_sim_cycle =" kern_infile_$kern | cut -f 2 -d '='`
	for (( cycle =0; cycle <= $maxcycles; cycle++ ))
	do
		echo "Cycle : $cycle"
		for (( core=0; core < $numcores; core++ ))
		do
			#echo "Core : $core"
			insts=`grep "GPUSim cycle : $cycle, Core : $core," kern_infile_$kern | cut -f 3 -d ',' | cut -f 2 -d ':' | cut -f 1 -d ']' | cut -f 2 -d '='`
	 		echo "$cycle,$insts" >> insts_kernel_$kern\_core_$core	
		done
	done
done
