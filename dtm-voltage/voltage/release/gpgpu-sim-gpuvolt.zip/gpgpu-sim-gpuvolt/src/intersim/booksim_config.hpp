#ifndef _BOOKSIM_CONFIG_HPP_
#define _BOOKSIM_CONFIG_HPP_

#include "config_utils.hpp"

class BookSimConfig : public Configuration {
public:
   BookSimConfig( );
};

#endif
