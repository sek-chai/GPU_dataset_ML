bool pred_lookup(int condition, int flags);
